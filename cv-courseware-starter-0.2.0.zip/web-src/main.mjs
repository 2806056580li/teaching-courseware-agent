import { bootLesson } from './lesson-view.mjs';
async function start(){try {
  const raw=document.querySelector('#lesson-data').textContent.trim();
  const payload=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(raw),c=>c.charCodeAt(0))));
  await bootLesson(payload);
} catch {
  document.querySelector('#app').textContent='课件数据读取失败。请使用随包文字材料，并让老师检查文件是否完整。';
}}
start();
