import { Scene, Color, PerspectiveCamera, WebGLRenderer, HemisphereLight, DirectionalLight, Group, Box3, Vector3, ArrowHelper, GridHelper, CanvasTexture, SpriteMaterial, Sprite, LoadingManager, SRGBColorSpace } from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

function axisLabel(text,color,position){
  const c=document.createElement('canvas');c.width=128;c.height=64;
  const ctx=c.getContext('2d');ctx.font='bold 38px sans-serif';ctx.fillStyle=color;ctx.fillText(text,6,46);
  const s=new Sprite(new SpriteMaterial({map:new CanvasTexture(c),depthTest:false}));
  s.position.copy(position);s.scale.set(.46,.23,1);return s;
}
export async function mountEulerScene({element,modelBytes,onStatus}){
  const scene=new Scene();scene.background=new Color('#f6f8f8');
  const camera=new PerspectiveCamera(36,1,.01,100);camera.position.set(4,3.1,4.8);
  const renderer=new WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.outputColorSpace=SRGBColorSpace;
  element.append(renderer.domElement);renderer.domElement.setAttribute('aria-label','三维模型观察视图');
  const controls=new OrbitControls(camera,renderer.domElement);controls.minDistance=3;controls.maxDistance=12;controls.enablePan=false;controls.saveState();
  scene.add(new HemisphereLight(0xffffff,0x7a8895,3));
  const key=new DirectionalLight(0xffffff,4);key.position.set(4,7,5);scene.add(key);
  const grid=new GridHelper(6,12,0xc9d1d3,0xe0e5e6);grid.position.y=-1.65;scene.add(grid);
  const pivot=new Group();scene.add(pivot);
  for(const [text,dir,col] of [['X',new Vector3(1,0,0),0xcd3f48],['Y',new Vector3(0,1,0),0x23825a],['Z',new Vector3(0,0,1),0x266fce]]){
    scene.add(new ArrowHelper(dir,new Vector3(),1.65,col,.16,.09));
    scene.add(axisLabel(text,'#'+col.toString(16),dir.clone().multiplyScalar(1.86)));
    pivot.add(new ArrowHelper(dir,new Vector3(),1.25,col,.1,.06));
  }
  let disposed=false;
  const render=()=>{if(!disposed)renderer.render(scene,camera);};
  const resize=new ResizeObserver(()=>{const {width,height}=element.getBoundingClientRect();if(width&&height){camera.aspect=width/height;camera.updateProjectionMatrix();renderer.setSize(width,height);render();}});resize.observe(element);
  controls.addEventListener('change',render);
  renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();onStatus('error','三维图形上下文已丢失，当前显示静态对照。');});
  let dependencyFailed=false;
  const manager=new LoadingManager();manager.onError=()=>{dependencyFailed=true;};
  manager.setURLModifier(url=>{if(!/^(blob:|data:)/.test(url))throw new Error('External model dependency blocked');return url;});
  try{
    const gltf=await new GLTFLoader(manager).parseAsync(modelBytes,'');
    if(dependencyFailed)throw new Error('Model texture failed to load');
    const box=new Box3().setFromObject(gltf.scene), center=box.getCenter(new Vector3()), size=box.getSize(new Vector3());
    if(!Number.isFinite(size.length())||size.length()===0)throw new Error('Empty model');
    gltf.scene.position.sub(center);const normalized=new Group();normalized.add(gltf.scene);normalized.scale.setScalar(2.05/Math.max(size.x,size.y,size.z));pivot.add(normalized);
    element.dataset.ready='true';onStatus('ready');render();
  }catch(e){resize.disconnect();controls.dispose();renderer.dispose();renderer.domElement.remove();throw e;}
  return {setPose(result){pivot.quaternion.fromArray(result.quaternion);render();},resetView(){controls.reset();render();},dispose(){disposed=true;resize.disconnect();controls.dispose();scene.traverse(o=>{o.geometry?.dispose();if(o.material)for(const m of [].concat(o.material)){m.map?.dispose();m.dispose();}});renderer.dispose();}};
}
