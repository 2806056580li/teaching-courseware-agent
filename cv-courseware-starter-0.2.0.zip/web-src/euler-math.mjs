import { Matrix4, Quaternion, Vector3, MathUtils } from 'three';

export function composeEuler({ angleX, angleY, order, step }) {
  if (![angleX,angleY].every(v=>typeof v==='number' && Number.isFinite(v) && Math.abs(v)<=180) || !['XY','YX'].includes(order) || ![0,1,2].includes(step)) throw new RangeError('Invalid Euler activity state');
  const x=new Matrix4().makeRotationX(MathUtils.degToRad(angleX));
  const y=new Matrix4().makeRotationY(MathUtils.degToRad(angleY));
  const first=order==='XY'?x:y, second=order==='XY'?y:x;
  const matrix=step===0?new Matrix4():step===1?first.clone():new Matrix4().multiplyMatrices(second,first);
  const e=matrix.elements;
  return {matrixRows:[e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]],vector:new Vector3(0,0,1).applyMatrix4(matrix).toArray(),quaternion:new Quaternion().setFromRotationMatrix(matrix).toArray()};
}
