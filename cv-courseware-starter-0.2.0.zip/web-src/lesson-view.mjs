import { createElement, RotateCcw, StepForward, Scan, Maximize } from 'lucide';
import { composeEuler } from './euler-math.mjs';
import { mountEulerScene } from './scene.mjs';

const el=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e;};
const num=v=>Math.abs(v)<.0005?'0':String(Number(v.toFixed(3)));
function iconButton(id,label,icon){const b=el('button','icon-button');b.id=id;b.title=label;b.setAttribute('aria-label',label);b.append(createElement(icon));return b;}

export async function bootLesson(payload){
  const p=payload.lesson, root=document.querySelector('#app');root.replaceChildren();
  const header=el('header','topbar'), heading=el('div');heading.append(el('span','eyebrow','计算机视觉 / 空间几何'),el('h1','',p.title));
  const full=iconButton('fullscreen','全屏',Maximize);full.onclick=()=>{const promise=document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen();promise?.catch(()=>{});};
  header.append(heading,full);root.append(header);
  const tabs=el('nav','tabs');tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','教学单元');root.append(tabs);
  const intro=el('section','intro'), unitTitle=el('h2'), pointLine=el('p','points');intro.append(unitTitle,pointLine);root.append(intro);
  const workspace=el('section','workspace');root.append(workspace);
  const scenes=[], matrixEls=[], vectorEls=[], formulaEls=[];
  const state={angleX:p.activity.angleX,angleY:p.activity.angleY,step:0};
  for(const [index,order] of ['XY','YX'].entries()){
    const panel=el('article','comparison'), bar=el('div','panel-heading');bar.append(el('h3','',order==='XY'?'先 X 后 Y':'先 Y 后 X'),el('span','axis-note','固定世界轴'));
    const viewport=el('div','scene'), fallback=el('div','fallback');fallback.hidden=true;
    const img=el('img');img.src=payload.fallback;img.alt='初始设定角度的静态向量对照，不随控件变化';fallback.append(el('p','fallback-status'),img);
    const formula=el('div','formula'), mat=el('div','matrix');mat.setAttribute('aria-label',order+' 旋转矩阵');
    const vec=el('div','vector-result');vec.setAttribute('aria-live','polite');
    const result=el('div','results');result.append(formula,mat,vec);panel.append(bar,viewport,fallback,result);workspace.append(panel);
    matrixEls.push(mat);vectorEls.push(vec);formulaEls.push(formula);
    const fail=message=>{viewport.hidden=true;fallback.hidden=false;fallback.querySelector('p').textContent=message+' 静态图仅对应初始设定；下方数值仍可计算。';};
    const bytes=Uint8Array.from(atob(payload.model),c=>c.charCodeAt(0));
    mountEulerScene({element:viewport,modelBytes:bytes.buffer,onStatus:(status,message)=>{if(status==='error')fail(message);}}).then(scene=>{scenes[index]=scene;update();}).catch(()=>fail('当前环境无法显示三维模型。'));
  }
  const toolbar=el('section','toolbar'), controls=el('div','angle-controls');toolbar.append(controls);
  const inputs=[];
  for(const [axis,key] of [['X','angleX'],['Y','angleY']]){
    const row=el('div','angle-row'),label=el('label','',axis+' 轴 / °');label.htmlFor=`angle-${axis.toLowerCase()}`;
    const range=el('input');range.type='range';range.min=-180;range.max=180;range.step=1;range.id=label.htmlFor;
    const n=el('input','number');n.type='number';n.min=-180;n.max=180;n.step=1;n.id=range.id+'-number';n.setAttribute('aria-label',axis+' 轴角度');
    range.value=n.value=state[key];
    range.oninput=()=>{state[key]=Number(range.value);n.value=range.value;update();};
    n.onchange=()=>{const value=Number(n.value);if(n.value!==''&&Number.isFinite(value)&&Math.abs(value)<=180){state[key]=value;range.value=value;}else n.value=state[key];update();};
    inputs.push({key,range,n});row.append(label,range,n);controls.append(row);
  }
  const actions=el('div','actions'),stepValue=el('output','','0 / 2');stepValue.id='step-value';stepValue.setAttribute('aria-label','旋转步骤');
  const next=iconButton('next-step','执行下一步旋转',StepForward);next.onclick=()=>{state.step=Math.min(2,state.step+1);update();};
  const view=iconButton('reset-view','复位观察视角',Scan);view.onclick=()=>scenes.forEach(s=>s?.resetView());
  const reset=iconButton('reset-all','重置实验',RotateCcw);reset.onclick=()=>{Object.assign(state,{angleX:p.activity.angleX,angleY:p.activity.angleY,step:0});inputs.forEach(i=>{i.range.value=i.n.value=state[i.key];});scenes.forEach(s=>s?.resetView());update();};
  actions.append(stepValue,next,view,reset);toolbar.append(actions);root.append(toolbar);
  const content=el('section','lesson-content'),levels=el('div','levels');levels.setAttribute('role','tablist');levels.setAttribute('aria-label','讲解深度');
  const explanations=el('div','explanations'),questions=el('div','questions');let level='standard';
  const explain=()=>{explanations.replaceChildren();for(const c of p.concepts){const section=el('section');section.append(el('h3','',c.title),el('p','',c[level]));explanations.append(section);}};
  for(const [key,label] of [['intuitive','直观'],['standard','标准'],['advanced','深入']]){
    const b=el('button','level-tab',label);b.setAttribute('role','tab');b.setAttribute('aria-selected',key===level);b.onclick=()=>{level=key;levels.querySelectorAll('button').forEach(t=>t.setAttribute('aria-selected',t===b));explain();};levels.append(b);
  }
  content.append(levels,explanations,questions);root.append(content);explain();
  function selectUnit(index){
    const u=p.units[index];unitTitle.textContent=u.title;pointLine.textContent=u.points.join(' · ');tabs.querySelectorAll('button').forEach((b,i)=>b.setAttribute('aria-selected',i===index));
    questions.replaceChildren();const kind=index===0?'diagnostic':index===5?'transfer':'guided';
    for(const q of p.exercises.filter(e=>e.kind===kind)){
      const section=el('section','question');section.append(el('h3','',kind==='diagnostic'?'课前检查':kind==='transfer'?'独立尝试':'预测与验证'),el('p','',q.prompt));
      for(const [i,h] of q.hints.entries()){const d=el('details');d.append(el('summary','',`提示 ${i+1}`),el('p','',h));section.append(d);}questions.append(section);
    }
  }
  p.units.forEach((u,i)=>{const b=el('button','unit-tab',`${String(i+1).padStart(2,'0')} ${['学习目标','坐标约定','顺序实验','矩阵表达','三维观察','迁移练习'][i]}`);b.setAttribute('role','tab');b.onclick=()=>selectUnit(i);tabs.append(b);});selectUnit(2);
  const footer=el('footer');footer.append(el('span','',`${p.lessonId} · ${p.revision} · ${p.reviewStatus==='draft'?'教师待审核':'教师已确认'}`),el('span','','模型：ToyCar / Khronos / CC0'));root.append(footer);
  function update(){
    ['XY','YX'].forEach((order,i)=>{const result=composeEuler({...state,order});scenes[i]?.setPose(result);
      matrixEls[i].replaceChildren(...result.matrixRows.map(v=>el('span','',num(v))));
      vectorEls[i].textContent=`R · (0, 0, 1) = (${result.vector.map(num).join(', ')})`;
      formulaEls[i].textContent=state.step===0?'R = I':state.step===1?`R = R${order[0].toLowerCase()}`:order==='XY'?'R = Ry · Rx':'R = Rx · Ry';
    });
    stepValue.textContent=`${state.step} / 2`;next.disabled=state.step===2;
  }
  update();window.addEventListener('pagehide',()=>scenes.forEach(s=>s?.dispose()),{once:true});
}
