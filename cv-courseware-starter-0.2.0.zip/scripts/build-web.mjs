import { build } from 'esbuild';
import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
const dest=await fs.stat('skills/cv-courseware').then(()=>'skills/cv-courseware/templates/web').catch(()=>'cv-courseware/templates/web');
await build({entryPoints:['web-src/main.mjs'],outfile:`${dest}/courseware.bundle.js`,bundle:true,format:'iife',minify:true,target:'es2020',legalComments:'inline',supported:{'top-level-await':false}});
const notices=[];
for(const pkg of ['three','lucide']){
  const meta=JSON.parse(await fs.readFile(`node_modules/${pkg}/package.json`,'utf8'));
  const candidates=['LICENSE','LICENSE.txt','LICENSE.md'];let license;
  for(const name of candidates){try{license=await fs.readFile(`node_modules/${pkg}/${name}`,'utf8');break;}catch{}}
  if(!license)throw new Error(`Missing license: ${pkg}`);notices.push(`# ${pkg} ${meta.version}\n\n${license}`);
}
await fs.writeFile(`${dest}/THIRD_PARTY_NOTICES.md`,notices.join('\n\n'));
const files=[];
for(const name of ['courseware.bundle.js','courseware.css','shell.html','THIRD_PARTY_NOTICES.md']){const b=await fs.readFile(path.join(dest,name));files.push({path:name,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex')});}
await fs.writeFile(`${dest}/bundle-manifest.json`,JSON.stringify({version:'0.2.0',files},null,2));
console.log(JSON.stringify({success:true,files:files.map(f=>({path:f.path,bytes:f.bytes}))}));
