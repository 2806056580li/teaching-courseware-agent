#requires -Version 5.1
function Publish-CvPackageArchive([string]$Stage,[string]$Output,[int]$ExpectedCount){
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $temporary=Join-Path ([IO.Path]::GetDirectoryName($Output)) ('package-'+[guid]::NewGuid().ToString('N')+'.partial')
    try {
        [IO.Compression.ZipFile]::CreateFromDirectory($Stage,$temporary,[IO.Compression.CompressionLevel]::Optimal,$false)
        $zip=[IO.Compression.ZipFile]::OpenRead($temporary)
        try {
            if($zip.Entries.Count -ne $ExpectedCount){throw 'ZIP entry count does not match the manifest.'}
            foreach($entry in $zip.Entries){
                if($entry.FullName -match '(?i)\.(pptx?|pdf|pem|key|pfx|p12)$|(^|[/\\])\.env'){throw ('Forbidden packaged file: '+$entry.FullName)}
            }
        }finally{$zip.Dispose()}
        [IO.File]::Move($temporary,$Output)
    }catch{throw ('Archive publication failed; diagnostic temporary file (if created): '+$temporary+'. '+$_.Exception.Message)}
}
