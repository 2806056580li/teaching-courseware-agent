#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ResourceDirectory,
    [Parameter(Mandatory=$true)][string]$OutputPath
)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$skill=Join-Path $root 'skills/cv-courseware'
if (-not (Test-Path -LiteralPath $skill -PathType Container)) { $skill=Join-Path $root 'cv-courseware' }
$output=[IO.Path]::GetFullPath($ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath))
if ([IO.Path]::GetExtension($output) -ne '.zip') { throw 'OutputPath must end in .zip.' }
if (Test-Path -LiteralPath $output) { throw 'Package output already exists; choose a new version.' }
if (-not (Test-Path -LiteralPath ([IO.Path]::GetDirectoryName($output)) -PathType Container)) { throw 'Output directory must already exist.' }
$cache=[IO.Path]::GetFullPath($ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($ResourceDirectory))
$catalog=Get-Content -LiteralPath (Join-Path $skill 'references/resource-catalog.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$engine=(Get-Process -Id $PID).Path
$verification=& $engine -NoProfile -File (Join-Path $skill 'scripts/Get-Resources.ps1') -Destination $cache -VerifyOnly
if ($LASTEXITCODE -ne 0) { throw ('Resource verification failed: ' + ($verification -join "`n")) }
$stage=Join-Path ([IO.Path]::GetDirectoryName($output)) ('package-stage-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($stage)
$files=New-Object 'System.Collections.Generic.List[object]'
function Assert-PublicValue {
    param($Value,[string]$Relative)
    if($null -eq $Value){return}
    if($Value -is [string]){
        if($Value -match '(?i)[A-Z]:[/\\]Users[/\\][^/\\\s]+[/\\]' -or $Value -match '(?i)(?:cv_pat_|ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{12,}') {throw ('Private path or credential pattern in '+$Relative)}
    }elseif($Value -is [pscustomobject]){
        foreach($property in $Value.PSObject.Properties){Assert-PublicValue $property.Name $Relative;Assert-PublicValue $property.Value $Relative}
    }elseif($Value -is [System.Collections.IEnumerable]){
        foreach($item in $Value){Assert-PublicValue $item $Relative}
    }
}
function Add-PackageFile {
    param([string]$Source,[string]$Relative,[switch]$CheckText)
    if ($Relative -match '(^|[/\\])\.\.([/\\]|$)' -or [IO.Path]::IsPathRooted($Relative)) { throw 'Unsafe package path.' }
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) { throw ('Missing package source: '+$Source) }
    if ($CheckText) {
        $body=Get-Content -LiteralPath $Source -Raw -Encoding UTF8
        Assert-PublicValue $body $Relative
        if([IO.Path]::GetExtension($Source) -eq '.json'){Assert-PublicValue (ConvertFrom-Json -InputObject $body) $Relative}
        if([IO.Path]::GetExtension($Source) -eq '.html'){
            $payload=[regex]::Match($body,'<script id="lesson-data" type="application/octet-stream">([^<]+)</script>')
            if($payload.Success -and -not($Relative -eq 'cv-courseware/templates/web/shell.html' -and $payload.Groups[1].Value -eq '__PAYLOAD__')){Assert-PublicValue ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($payload.Groups[1].Value))|ConvertFrom-Json) $Relative}
        }
    }
    $destination=Join-Path $stage $Relative
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($destination))
    Copy-Item -LiteralPath $Source -Destination $destination
    $files.Add([ordered]@{path=$Relative.Replace('\','/');bytes=(Get-Item -LiteralPath $destination).Length;sha256=(Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant()})
}
$releaseFiles=@(
    'SKILL.md',
    'scripts/Build-Courseware.ps1','scripts/Courseware.Core.ps1','scripts/Test-Lesson.ps1',
    'scripts/Test-Environment.ps1','scripts/Get-Resources.ps1',
    'references/lesson-format.md','references/resource-catalog.json','references/teaching-checklist.md',
    'references/compatibility.md','references/course-map.md','templates/example.json',
    'scripts/LessonPack.Core.ps1','scripts/LessonPack.Export.ps1','scripts/LessonPack.Figures.ps1',
    'scripts/Test-LessonPack.ps1','scripts/Build-LessonPack.ps1',
    'references/lesson-pack-format.md','references/student-tutoring.md','references/teacher-acceptance.md',
    'templates/euler/lesson-pack.json','templates/euler/teacher-guide.md',
    'templates/web/shell.html','templates/web/courseware.css','templates/web/courseware.bundle.js',
    'templates/web/THIRD_PARTY_NOTICES.md','templates/web/bundle-manifest.json'
)
foreach ($relative in $releaseFiles) {
    Add-PackageFile (Join-Path $skill $relative) ('cv-courseware/'+$relative) -CheckText
}
foreach ($name in @('INSTALL.md','demo-3d.json','TEST_REPORT.md')) { Add-PackageFile (Join-Path $root $name) $name -CheckText }
foreach ($name in @('test-input.ps1','test-build.ps1','test-resources.ps1','test-package.ps1','test-lesson-pack.ps1','test-lesson-pack-export.ps1','test-teacher-install.ps1','test-review-regressions.ps1','euler-math.test.mjs','lesson-pack-browser.test.mjs','lesson-pack-fallback.test.mjs')) { Add-PackageFile (Join-Path $root ('tests/'+$name)) ('tests/'+$name) -CheckText }
Add-PackageFile (Join-Path $root 'scripts/Pack-Skill.ps1') 'scripts/Pack-Skill.ps1' -CheckText
Add-PackageFile (Join-Path $root 'scripts/Package.Archive.ps1') 'scripts/Package.Archive.ps1' -CheckText
foreach($name in @('package.json','pnpm-lock.yaml','scripts/build-web.mjs','web-src/main.mjs','web-src/scene.mjs','web-src/euler-math.mjs','web-src/lesson-view.mjs')){Add-PackageFile (Join-Path $root $name) $name -CheckText}
foreach ($resource in $catalog.resources) {
    Add-PackageFile (Join-Path $cache $resource.path) ('resources/'+$resource.path)
}
$demoRoot=Join-Path ([IO.Path]::GetDirectoryName($output)) ('example-stage-'+[guid]::NewGuid().ToString('N'))
. (Join-Path $skill 'scripts/LessonPack.Export.ps1')
$demo=New-CvLessonPackBundle -PackPath (Join-Path $skill 'templates/euler/lesson-pack.json') -ResourceDirectory $cache -OutputDirectory $demoRoot
foreach($name in @('teacher/lesson-plan.md','teacher/teacher-guide.md','student/learning-pack.json','student/learning-pack.md','student/START.txt','student/learning-record.md','student/lesson.html','student/THIRD_PARTY_NOTICES.md','student/MODEL_LICENSE.md','ppt/lesson.json','ppt/assets/axes.png','ppt/assets/order-comparison.png','ppt/assets/math-state.json','ppt/assets/model.glb','build-report.json')){
    $isText=[IO.Path]::GetExtension($name) -in @('.md','.json','.txt','.html')
    Add-PackageFile (Join-Path $demoRoot $name) ('examples/euler/'+$name) -CheckText:$isText
}
$record=[ordered]@{schemaVersion=1;version='0.2.0';containsTeacherMaterials=$false;privacyReview='Explicit release allowlist plus path/token checks; approved file contents still require maintainer review.';resources=$catalog.resources.Count;files=@($files.ToArray())}
$record | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $stage 'package-manifest.json') -Encoding UTF8
$check=& $engine -NoProfile -File (Join-Path $stage 'cv-courseware/scripts/Test-Lesson.ps1') -LessonPath (Join-Path $stage 'demo-3d.json')
if ($LASTEXITCODE -ne 0) { throw ('Packaged demo is invalid: '+($check -join "`n")) }
. (Join-Path $PSScriptRoot 'Package.Archive.ps1')
Publish-CvPackageArchive $stage $output ($files.Count+1)
[pscustomobject]@{success=$true;output=$output;bytes=(Get-Item -LiteralPath $output).Length;sha256=(Get-FileHash -LiteralPath $output -Algorithm SHA256).Hash.ToLowerInvariant();fileCount=$files.Count+1;resourceCount=$catalog.resources.Count;staging=$stage} | ConvertTo-Json -Depth 4
