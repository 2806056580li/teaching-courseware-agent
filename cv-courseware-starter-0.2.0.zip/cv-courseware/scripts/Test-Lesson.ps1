#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$LessonPath)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Courseware.Core.ps1')
$result = Test-CoursewareLesson -LessonPath $LessonPath
$result | Select-Object valid,lessonPath,topicCount,physicalSlideCount,errors | ConvertTo-Json -Depth 8
if (-not $result.valid) { exit 1 }
exit 0
