﻿#requires -Version 5.1
. (Join-Path $PSScriptRoot 'Courseware.Core.ps1')

function Assert-CvSafeAncestors([string]$Path) {
    $current=[IO.Path]::GetFullPath($Path)
    while($current){
        if(Test-Path -LiteralPath $current){
            if((Get-Item -LiteralPath $current -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse points are not allowed.'}
        }
        $current=[IO.Path]::GetDirectoryName($current)
    }
}
function Assert-CvText($Value,[int]$Maximum,[string]$Field,[switch]$Empty,[switch]$Multiline){
    Assert-CoursewareText $Value $Maximum $Field -AllowEmpty:$Empty -Multiline:$Multiline
    if($Value -match '(?is)<\s*[!/?a-z]|javascript\s*:'){Stop-CoursewareValidation 'markup' $Field 'Use plain text, not executable markup.'}
}
function Assert-CvArray($Value,[int]$Minimum,[int]$Maximum,[string]$Field){
    if($Value -isnot [array] -or $Value.Count -lt $Minimum -or $Value.Count -gt $Maximum){Stop-CoursewareValidation 'array' $Field "Expected array of $Minimum to $Maximum items."}
}
function Assert-CvNumber($Value,[double]$Minimum,[double]$Maximum,[string]$Field,[switch]$Integer){
    if($Value -isnot [ValueType] -or $Value -is [bool] -or $Value -is [char]){Stop-CoursewareValidation 'number' $Field 'Expected a number.'}
    $n=[double]$Value
    if([double]::IsNaN($n) -or [double]::IsInfinity($n) -or $n -lt $Minimum -or $n -gt $Maximum -or ($Integer -and [math]::Floor($n) -ne $n)){Stop-CoursewareValidation 'number' $Field 'Number is outside the allowed range.'}
}
function Assert-CvId($Value,[string]$Field){
    if($Value -isnot [string] -or $Value -cnotmatch '^[a-z][a-z0-9-]{0,63}$'){Stop-CoursewareValidation 'id' $Field 'Expected a lowercase identifier.'}
}
function Get-CvIds($Items,[string]$Field){
    $ids=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
    foreach($item in $Items){Assert-CvId $item.id "$Field.id";if(-not$ids.Add($item.id)){Stop-CoursewareValidation 'id' $Field 'Duplicate identifier.'}}
    return ,$ids
}
function Assert-CvRefs($Refs,$Ids,[string]$Field,[int]$Minimum=0){
    Assert-CvArray $Refs $Minimum 20 $Field
    $seen=@{}
    foreach($id in $Refs){Assert-CvId $id $Field;if(-not$Ids.Contains($id) -or $seen.ContainsKey($id)){Stop-CoursewareValidation 'reference' $Field 'Unknown or repeated reference.'};$seen[$id]=$true}
}
function Assert-CvTexts($Values,[int]$Count,[int]$Length,[string]$Field){
    Assert-CvArray $Values 0 $Count $Field
    foreach($v in $Values){Assert-CvText $v $Length $Field}
}
function Read-CvJson([string]$Path,[int]$Maximum=2097152){
    if(-not[IO.File]::Exists($Path)){throw 'JSON file does not exist.'}
    if((Get-Item -LiteralPath $Path).Length -gt $Maximum){throw 'JSON file exceeds size limit.'}
    Assert-CvSafeAncestors $Path
    $bytes=[IO.File]::ReadAllBytes($Path)
    $text=(New-Object Text.UTF8Encoding($false,$true)).GetString($bytes).TrimStart([char]0xfeff)
    Assert-CoursewareJson $text
    return ConvertFrom-Json -InputObject $text -ErrorAction Stop
}
function Assert-CvEmbeddedGlb([string]$Path){
    $b=[IO.File]::ReadAllBytes($Path)
    if($b.Length -lt 20 -or [BitConverter]::ToUInt32($b,0) -ne 0x46546c67 -or [BitConverter]::ToUInt32($b,4) -ne 2 -or [BitConverter]::ToUInt32($b,8) -ne $b.Length){throw 'Invalid GLB header.'}
    $length=[BitConverter]::ToUInt32($b,12)
    if($length -gt 2097152 -or ($length+20) -gt $b.Length -or [BitConverter]::ToUInt32($b,16) -ne 0x4e4f534a){throw 'Invalid GLB JSON chunk.'}
    $j=(New-Object Text.UTF8Encoding($false,$true)).GetString($b,20,$length).TrimEnd([char]0,' ')
    Assert-CoursewareJson $j
    $g=$j|ConvertFrom-Json
    foreach($entry in @($g.buffers)+@($g.images)){
        if($null -ne $entry -and $entry.PSObject.Properties['uri'] -and $entry.uri -notmatch '^data:'){throw 'External GLB URI is forbidden.'}
    }
    foreach($ext in @($g.extensionsRequired)){
        if($ext -in @('KHR_draco_mesh_compression','KHR_texture_basisu','EXT_meshopt_compression')){throw 'External model decoder is not supported.'}
    }
}
function Get-CvUnitNotes($Pack,$Unit){
    $notes=$Unit.notes+"`r`nLesson: $($Pack.lessonId) / $($Pack.revision); Unit: $($Unit.id); Objectives: "+($Unit.objectiveIds -join ', ')
    foreach($id in $Unit.sourceIds){$source=$Pack.sources|Where-Object id -ceq $id;$notes+="`r`n$($source.title): $($source.citation)"}
    return $notes
}
function Read-CvLessonPack {
    param([string]$PackPath,[string]$ResourceDirectory)
    $full=Resolve-CoursewareUserPath $PackPath
    $root=[IO.Path]::GetDirectoryName($full)
    $p=Read-CvJson $full
    Assert-CoursewareFields $p @('schemaVersion','lessonId','revision','title','audience','durationMinutes','language','reviewStatus','sources','objectives','concepts','activity','exercises','units','teacherGuide') -Field '$'
    Assert-CvNumber $p.schemaVersion 1 1 'schemaVersion' -Integer
    Assert-CvId $p.lessonId 'lessonId'
    if($p.revision -isnot [string] -or $p.revision -notmatch '^\d+\.\d+\.\d+$' -or $p.revision.Length -gt 32){throw 'Invalid revision.'}
    Assert-CvText $p.title 80 'title';Assert-CvText $p.audience 160 'audience'
    Assert-CvNumber $p.durationMinutes 5 180 'durationMinutes' -Integer
    if($p.language -cne 'zh-CN' -or $p.reviewStatus -cnotin @('draft','teacher-approved')){throw 'Invalid language or reviewStatus.'}
    Assert-CvArray $p.sources 0 20 'sources'
    foreach($s in $p.sources){
        Assert-CoursewareFields $s @('id','title','citation','pages','shareWithStudents') -Field 'sources'
        Assert-CvText $s.title 160 'sources.title';Assert-CvText $s.citation 1000 'sources.citation'
        if($s.shareWithStudents -isnot [bool]){throw 'Source visibility must be boolean.'}
        if($s.shareWithStudents -and $s.citation -match '(?i)(?<![a-z])[a-z]:[/\\]|\\\\|file:'){throw 'Private path in shareable source.'}
        Assert-CvArray $s.pages 0 20 'sources.pages';foreach($n in $s.pages){Assert-CvNumber $n 1 100000 'sources.pages' -Integer}
    }
    Assert-CvArray $p.objectives 1 6 'objectives'
    foreach($o in $p.objectives){Assert-CoursewareFields $o @('id','text','prerequisites') -Field 'objectives';Assert-CvText $o.text 200 'objectives.text';Assert-CvTexts $o.prerequisites 6 120 'objectives.prerequisites'}
    $sourceIds=Get-CvIds $p.sources 'sources';$objectiveIds=Get-CvIds $p.objectives 'objectives'
    Assert-CvArray $p.concepts 1 12 'concepts'
    foreach($c in $p.concepts){
        Assert-CoursewareFields $c @('id','title','intuitive','standard','advanced','misconceptions','objectiveIds','sourceIds') -Field 'concepts'
        Assert-CvText $c.title 80 'concepts.title'
        foreach($key in @('intuitive','standard','advanced')){Assert-CvText $c.$key 1200 "concepts.$key" -Multiline}
        Assert-CvTexts $c.misconceptions 6 200 'misconceptions'
        Assert-CvRefs $c.objectiveIds $objectiveIds 'concepts.objectiveIds' 1;Assert-CvRefs $c.sourceIds $sourceIds 'concepts.sourceIds'
    }
    $null=Get-CvIds $p.concepts 'concepts'
    Assert-CoursewareFields $p.activity @('kind','angleX','angleY','modelResourceId') -Field 'activity'
    if($p.activity.kind -cne 'euler-order' -or $p.activity.modelResourceId -cne 'khronos-models-toycar-gltf-binary-toycar-glb'){throw 'Unsupported activity or model.'}
    Assert-CvNumber $p.activity.angleX -180 180 'activity.angleX';Assert-CvNumber $p.activity.angleY -180 180 'activity.angleY'
    Assert-CvArray $p.exercises 5 12 'exercises'
    foreach($e in $p.exercises){
        Assert-CoursewareFields $e @('id','kind','prompt','hints','objectiveIds') -Field 'exercises'
        if($e.kind -cnotin @('diagnostic','guided','transfer')){throw 'Invalid exercise kind.'}
        Assert-CvText $e.prompt 1000 'exercises.prompt' -Multiline;Assert-CvTexts $e.hints 3 400 'exercises.hints'
        Assert-CvRefs $e.objectiveIds $objectiveIds 'exercises.objectiveIds' 1
    }
    $null=Get-CvIds $p.exercises 'exercises'
    if(@($p.exercises|Where-Object kind -eq diagnostic).Count -ne 3 -or @($p.exercises|Where-Object kind -eq guided).Count -lt 1 -or @($p.exercises|Where-Object kind -eq transfer).Count -lt 1){throw 'Require three diagnostic, one guided and one transfer exercise.'}
    Assert-CvArray $p.units 6 6 'units';$kinds=@('goals','axes','order','matrix','observation','summary')
    for($i=0;$i -lt 6;$i++){
        $u=$p.units[$i]
        Assert-CoursewareFields $u @('id','kind','title','points','notes','objectiveIds','sourceIds') -Field 'units'
        if($u.kind -cne $kinds[$i]){throw 'Invalid unit sequence.'}
        Assert-CvText $u.title 40 'units.title';Assert-CvTexts $u.points 3 48 'units.points';Assert-CvText $u.notes 8000 'units.notes' -Empty -Multiline
        Assert-CvRefs $u.objectiveIds $objectiveIds 'units.objectiveIds' 1;Assert-CvRefs $u.sourceIds $sourceIds 'units.sourceIds'
        if((Get-CvUnitNotes $p $u).Length -gt 8000){Stop-CoursewareValidation 'notes-length' "units[$i].notes" 'Notes plus generated lesson metadata and source citations must fit 8000 characters. Move extended teaching notes into teacherGuide.'}
    }
    $null=Get-CvIds $p.units 'units'
    $guide=Resolve-CoursewareAsset $root $p.teacherGuide @('.md') 'teacherGuide'
    if((Get-Item -LiteralPath $guide).Length -gt 262144){throw 'Teacher guide exceeds 256 KiB.'}
    $catalog=Read-CvJson (Join-Path $PSScriptRoot '../references/resource-catalog.json')
    $resource=@($catalog.resources|Where-Object id -ceq $p.activity.modelResourceId)
    if($resource.Count -ne 1){throw 'Model is absent from catalog.'}
    $cache=Resolve-CoursewareUserPath $ResourceDirectory;Assert-CvSafeAncestors $cache
    $model=Resolve-CoursewareAsset $cache $resource[0].path @('.glb') 'model'
    if((Get-Item -LiteralPath $model).Length -ne $resource[0].bytes -or (Get-FileHash -LiteralPath $model -Algorithm SHA256).Hash -ine $resource[0].sha256){throw 'Model size or SHA256 mismatch.'}
    Assert-CvEmbeddedGlb $model
    [pscustomobject]@{pack=$p;root=$root;modelPath=$model;teacherGuidePath=$guide;inputHash=(Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToLowerInvariant()}
}
function Test-CvLessonPack {
    param([string]$PackPath,[string]$ResourceDirectory)
    try{$d=Read-CvLessonPack $PackPath $ResourceDirectory;[pscustomobject]@{valid=$true;lessonId=$d.pack.lessonId;revision=$d.pack.revision;errors=@()}}
    catch{[pscustomobject]@{valid=$false;lessonId=$null;revision=$null;errors=@([pscustomobject]@{code='lesson-pack';path=[string]$_.Exception.Data['CoursewareField'];message=$_.Exception.Message})}}
}
