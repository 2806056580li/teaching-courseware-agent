﻿#requires -Version 5.1
<#
.SYNOPSIS
下载或离线校验课程资源，标准输出为 JSON，失败返回非零退出码。
.PARAMETER Destination
必填下载根目录；运行时检查以便缺失参数也返回 JSON，不触发交互提示。
.PARAMETER Topics
可选主题数组，每项也可用逗号分隔。默认全部，始终附加 common。
.PARAMETER Catalog
可选 JSON 文件或包含 resource-catalog.json 的目录；默认使用随 Skill 发布的清单。
.PARAMETER VerifyOnly
只校验本地文件，不联网、不创建目录、不修复文件。
.PARAMETER Force
允许原子替换哈希或大小不符的文件；正确缓存仍然跳过。
.EXAMPLE
.\Get-Resources.ps1 -Destination '.\课程资源' -Topics 'calibration,structured-light'
.EXAMPLE
.\Get-Resources.ps1 -Destination '.\课程资源' -VerifyOnly
#>
[CmdletBinding()]
param(
    [AllowEmptyString()][string]$Destination,
    [string[]]$Topics,
    [switch]$VerifyOnly,
    [string]$Catalog,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$knownTopics = @('common','geometry','features','calibration','stereo','structured-light','texture','deep-learning')
$results = New-Object 'System.Collections.Generic.List[object]'
$errors = New-Object 'System.Collections.Generic.List[object]'
$report = [ordered]@{schemaVersion=1;success=$false;mode='download';selected=0;downloaded=0;cached=0;verified=0;failed=0;resources=@();errors=@()}
if ($VerifyOnly) { $report.mode = 'verify' }

function Stop-Resource {
    param([string]$Code, [string]$Message)
    $exception = New-Object System.ArgumentException($Message)
    $exception.Data['ResourceCode'] = $Code
    throw $exception
}

function Assert-Fields {
    param($Value, [string[]]$Fields)
    if ($null -eq $Value -or $Value -isnot [pscustomobject]) { Stop-Resource 'catalog' 'Expected a JSON object.' }
    $actual = @($Value.PSObject.Properties.Name)
    foreach ($field in $Fields) {
        if ($actual -cnotcontains $field) { Stop-Resource 'catalog' ('Missing field: ' + $field) }
    }
    foreach ($field in $actual) {
        if ($Fields -cnotcontains $field) { Stop-Resource 'catalog' ('Unknown field: ' + $field) }
    }
}

function Assert-JsonTokens {
    param([string]$Json)
    # Both engines discard some duplicate JSON keys; reject them before conversion.
    $pattern = '"(?:[^"\\\x00-\x1F]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"|[{}\[\]:,]|true|false|null|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?'
    $tokens = [regex]::Matches($Json, $pattern)
    $stack = New-Object 'System.Collections.Generic.List[object]'
    $offset = 0
    for ($index=0; $index -lt $tokens.Count; $index++) {
        $token = $tokens[$index]
        if ($Json.Substring($offset,$token.Index-$offset).Trim().Length) { Stop-Resource 'catalog' 'Invalid JSON token or comment.' }
        $offset = $token.Index + $token.Length
        $value = $token.Value
        if ($value -eq '{' -or $value -eq '[') {
            if ($stack.Count -ge 16) { Stop-Resource 'catalog' 'JSON nesting exceeds 16 levels.' }
            $stack.Add([pscustomobject]@{kind=$value;keys=(New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase))})
        }
        elseif ($value -eq '}' -or $value -eq ']') {
            if ($stack.Count -eq 0 -or ($index -gt 0 -and $tokens[$index-1].Value -eq ',')) { Stop-Resource 'catalog' 'Unbalanced JSON or trailing comma.' }
            $expected = '['
            if ($value -eq '}') { $expected = '{' }
            if ($stack[$stack.Count-1].kind -ne $expected) { Stop-Resource 'catalog' 'Mismatched JSON delimiters.' }
            $stack.RemoveAt($stack.Count-1)
        }
        elseif ($value.StartsWith('"') -and $index+1 -lt $tokens.Count -and $tokens[$index+1].Value -eq ':') {
            if ($stack.Count -eq 0 -or $stack[$stack.Count-1].kind -ne '{') { Stop-Resource 'catalog' 'Invalid JSON property.' }
            $key = (ConvertFrom-Json -InputObject ('{"key":' + $value + '}')).key
            if (-not $stack[$stack.Count-1].keys.Add($key)) { Stop-Resource 'catalog' ('Duplicate JSON key: ' + $key) }
        }
    }
    if ($stack.Count -ne 0 -or $Json.Substring($offset).Trim().Length) { Stop-Resource 'catalog' 'Incomplete JSON.' }
}

function Assert-PinnedUrl {
    param($Value)
    # The bundled catalog uses immutable GitHub raw commit URLs, including license evidence.
    if ($Value -isnot [string] -or $Value -cnotmatch '^https://raw\.githubusercontent\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/[a-f0-9]{40}/[A-Za-z0-9_./-]+$') {
        Stop-Resource 'url' 'Only HTTPS raw.githubusercontent.com URLs pinned to a full commit are allowed.'
    }
    foreach ($segment in $Value.Substring('https://'.Length).Split('/')) {
        if ($segment -in @('', '.', '..')) { Stop-Resource 'url' 'Ambiguous URL segments are forbidden.' }
    }
}

function Get-RelativeResourcePath {
    param($Value)
    if ($Value -isnot [string] -or [string]::IsNullOrWhiteSpace($Value) -or [IO.Path]::IsPathRooted($Value) -or $Value -match '[:<>"|?*\x00-\x1F\x7F]') {
        Stop-Resource 'path' 'Resource paths must be relative, without drive, UNC or alternate data stream syntax.'
    }
    $parts = @($Value -split '[\\/]')
    foreach ($part in $parts) {
        if ($part -in @('', '.', '..') -or $part -match '[. ]$' -or $part -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)') {
            Stop-Resource 'path' 'Traversal, empty segments, device names and ambiguous suffixes are forbidden.'
        }
    }
    return ($parts -join '/')
}

function Assert-NoReparsePath {
    param([string]$FullPath)
    $current = $FullPath
    while ($current) {
        try {
            $attributes = [IO.File]::GetAttributes($current)
            if (($attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { Stop-Resource 'path' 'Symlinks and junctions are not allowed in the download path.' }
        }
        catch {
            $cause = $_.Exception.GetBaseException()
            if ($cause -isnot [IO.FileNotFoundException] -and $cause -isnot [IO.DirectoryNotFoundException]) { throw }
        }
        $current = [IO.Path]::GetDirectoryName($current)
    }
}

function Test-ResourceFile {
    param([string]$File, $Resource)
    if (-not [IO.File]::Exists($File)) { return $false }
    if ((Get-Item -LiteralPath $File -Force).Length -ne $Resource.bytes) { return $false }
    return ((Get-FileHash -LiteralPath $File -Algorithm SHA256).Hash -ieq $Resource.sha256)
}

function Add-Failure {
    param($Exception, [string]$Id, [string]$Path)
    $code = 'io'
    if ($Exception.Data.Contains('ResourceCode')) { $code = [string]$Exception.Data['ResourceCode'] }
    $errors.Add([pscustomobject]@{id=$Id;path=$Path;code=$code;message=$Exception.Message})
}

try {
    if (-not $PSBoundParameters.ContainsKey('Catalog')) { $Catalog = Join-Path $PSScriptRoot '../references/resource-catalog.json' }
    if ([string]::IsNullOrWhiteSpace($Destination)) { Stop-Resource 'destination' 'Destination is required.' }
    $destinationRoot = [IO.Path]::GetFullPath($ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Destination))
    $prefix = $destinationRoot.TrimEnd([char[]]'\/') + [IO.Path]::DirectorySeparatorChar
    if ([string]::IsNullOrWhiteSpace($Catalog)) { Stop-Resource 'catalog' 'Catalog is required.' }
    $catalogPath = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Catalog)
    if ([IO.Directory]::Exists($catalogPath)) { $catalogPath = Join-Path $catalogPath 'resource-catalog.json' }
    if (-not [IO.File]::Exists($catalogPath)) { Stop-Resource 'catalog' 'Catalog file does not exist.' }
    if ((Get-Item -LiteralPath $catalogPath).Length -gt 2097152) { Stop-Resource 'catalog' 'Catalog exceeds 2 MiB.' }
    $json = [IO.File]::ReadAllText($catalogPath, (New-Object Text.UTF8Encoding($false,$true)))
    Assert-JsonTokens $json
    $data = ConvertFrom-Json -InputObject $json
    Assert-Fields $data @('schemaVersion','resources')
    if (($data.schemaVersion -isnot [int] -and $data.schemaVersion -isnot [long]) -or $data.schemaVersion -ne 1) { Stop-Resource 'catalog' 'schemaVersion must be the integer 1.' }
    if ($data.resources -isnot [array] -or $data.resources.Count -eq 0) { Stop-Resource 'catalog' 'resources must be a nonempty array.' }
    $ids = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $paths = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $plans = New-Object 'System.Collections.Generic.List[object]'
    foreach ($resource in $data.resources) {
        Assert-Fields $resource @('id','topic','path','url','sha256','bytes','license','licenseUrl','description')
        foreach ($field in @('id','topic','license','description')) {
            if ($resource.$field -isnot [string] -or [string]::IsNullOrWhiteSpace($resource.$field) -or $resource.$field -match '[\x00-\x1F\x7F]') { Stop-Resource 'catalog' ('Invalid text field: ' + $field) }
        }
        if ($knownTopics -cnotcontains $resource.topic) { Stop-Resource 'topic' ('Unknown catalog topic: ' + $resource.topic) }
        if (-not $ids.Add($resource.id)) { Stop-Resource 'catalog' ('Duplicate resource id: ' + $resource.id) }
        if ($resource.sha256 -isnot [string] -or $resource.sha256 -notmatch '^[a-f0-9]{64}$') { Stop-Resource 'catalog' 'sha256 must contain exactly 64 hexadecimal characters.' }
        if (($resource.bytes -isnot [int] -and $resource.bytes -isnot [long]) -or $resource.bytes -le 0) { Stop-Resource 'catalog' 'bytes must be a positive integer.' }
        Assert-PinnedUrl $resource.url
        Assert-PinnedUrl $resource.licenseUrl
        $relative = Get-RelativeResourcePath $resource.path
        if (-not $paths.Add($relative)) { Stop-Resource 'path' ('Duplicate resource path: ' + $relative) }
        $target = [IO.Path]::GetFullPath((Join-Path $destinationRoot ($relative.Replace('/', [IO.Path]::DirectorySeparatorChar))))
        if (-not $target.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { Stop-Resource 'path' 'Resource escapes the destination.' }
        $plans.Add([pscustomobject]@{resource=$resource;relative=$relative;target=$target})
    }
    foreach ($plan in $plans) {
        $parent = $plan.relative
        while ($parent.Contains('/')) {
            $parent = $parent.Substring(0,$parent.LastIndexOf('/'))
            if ($paths.Contains($parent)) { Stop-Resource 'path' 'Resource file and directory paths collide.' }
        }
        $license = @($data.resources | Where-Object { $_.url -ceq $plan.resource.licenseUrl -and ($_.topic -ceq 'common' -or $_.id -ceq $plan.resource.id) })
        if ($license.Count -eq 0) { Stop-Resource 'catalog' ('License evidence must be the resource itself or a common resource: ' + $plan.resource.id) }
    }
    $selectedTopics = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
    if (-not $PSBoundParameters.ContainsKey('Topics')) {
        foreach ($topic in $knownTopics) { [void]$selectedTopics.Add($topic) }
    }
    else {
        if ($null -eq $Topics -or $Topics.Count -eq 0) { Stop-Resource 'topic' 'Topics cannot be empty.' }
        foreach ($item in $Topics) {
            foreach ($part in ($item -split ',')) {
                $topic = $part.Trim()
                if ($knownTopics -cnotcontains $topic) { Stop-Resource 'topic' ('Unknown or empty selected topic: ' + $topic) }
                [void]$selectedTopics.Add($topic)
            }
        }
    }
    [void]$selectedTopics.Add('common')
    $selected = @($plans | Where-Object { $selectedTopics.Contains($_.resource.topic) })
    $report.selected = $selected.Count
    Assert-NoReparsePath $destinationRoot
    if ([IO.File]::Exists($destinationRoot)) { Stop-Resource 'path' 'Destination is a file.' }
    foreach ($plan in $selected) {
        Assert-NoReparsePath $plan.target
        if ([IO.Directory]::Exists($plan.target)) { Stop-Resource 'path' 'Resource target is a directory.' }
        $parent = [IO.Path]::GetDirectoryName($plan.target)
        while ($parent -and $parent.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) {
            if ([IO.File]::Exists($parent)) { Stop-Resource 'path' 'Resource parent is a file.' }
            $parent = [IO.Path]::GetDirectoryName($parent)
        }
    }
    foreach ($plan in $selected) {
        $resource = $plan.resource
        $temporary = $null
        try {
            Assert-NoReparsePath $plan.target
            if (Test-ResourceFile $plan.target $resource) {
                $status = 'cached'
                if ($VerifyOnly) { $status = 'verified'; $report.verified++ }
                else { $report.cached++ }
            }
            else {
                $exists = [IO.File]::Exists($plan.target)
                if ($VerifyOnly) { Stop-Resource 'verify' ('File is missing or fails size/SHA256 verification: ' + $plan.relative) }
                if ($exists -and -not $Force) { Stop-Resource 'mismatch' ('Existing file differs; use -Force to replace it: ' + $plan.relative) }
                $parent = [IO.Path]::GetDirectoryName($plan.target)
                [void][IO.Directory]::CreateDirectory($parent)
                Assert-NoReparsePath $plan.target
                $temporary = Join-Path $parent ([IO.Path]::GetRandomFileName())
                $reservation = [IO.File]::Open($temporary,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
                $reservation.Dispose()
                $oldTls = [Net.ServicePointManager]::SecurityProtocol
                try {
                    [Net.ServicePointManager]::SecurityProtocol = $oldTls -bor [Net.SecurityProtocolType]::Tls12
                    $null = Invoke-WebRequest -Uri $resource.url -OutFile $temporary -UseBasicParsing -MaximumRedirection 0 -TimeoutSec 60 -ErrorAction Stop
                }
                finally { [Net.ServicePointManager]::SecurityProtocol = $oldTls }
                if (-not (Test-ResourceFile $temporary $resource)) { Stop-Resource 'integrity' ('Downloaded bytes or SHA256 do not match: ' + $plan.relative) }
                Assert-NoReparsePath $plan.target
                if ([IO.File]::Exists($plan.target)) {
                    if (-not $Force) { Stop-Resource 'conflict' 'A target appeared during download; it was not overwritten.' }
                    [IO.File]::Replace($temporary,$plan.target,[NullString]::Value)
                }
                else { [IO.File]::Move($temporary,$plan.target) }
                $temporary = $null
                $status = 'downloaded'
                $report.downloaded++
            }
            $results.Add([pscustomobject]@{id=$resource.id;path=$plan.relative;status=$status;bytes=$resource.bytes})
        }
        catch {
            $report.failed++
            Add-Failure $_.Exception $resource.id $plan.relative
            $results.Add([pscustomobject]@{id=$resource.id;path=$plan.relative;status='failed'})
        }
        finally {
            if ($temporary -and [IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) }
        }
    }
}
catch { Add-Failure $_.Exception '' '' }
$report.resources = @($results.ToArray())
$report.errors = @($errors.ToArray())
$report.success = ($errors.Count -eq 0)
ConvertTo-Json -InputObject $report -Depth 8 -Compress
if (-not $report.success) { exit 1 }
exit 0
