﻿#requires -Version 5.1
param([Parameter(Mandatory=$true)][string]$PackPath,[Parameter(Mandatory=$true)][string]$ResourceDirectory)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'LessonPack.Core.ps1')
$result=Test-CvLessonPack $PackPath $ResourceDirectory
$result|ConvertTo-Json -Depth 6
if($result.valid){exit 0}else{exit 1}
