#requires -Version 5.1

function Resolve-CoursewareUserPath {
    param([Parameter(Mandatory=$true)][string]$Path)
    $provider=$null; $drive=$null
    $providerPath=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path,[ref]$provider,[ref]$drive)
    if ($provider.Name -ne 'FileSystem') { throw 'Courseware paths must use the FileSystem provider.' }
    return [IO.Path]::GetFullPath($providerPath)
}

function Stop-CoursewareValidation {
    param([string]$Code, [string]$Field, [string]$Message)
    $exception = New-Object System.ArgumentException($Message)
    $exception.Data['CoursewareCode'] = $Code
    $exception.Data['CoursewareField'] = $Field
    throw $exception
}

function Assert-CoursewareFields {
    param($Value, [string[]]$Required, [string[]]$Optional = @(), [string]$Field)
    if ($null -eq $Value -or $Value -isnot [pscustomobject]) {
        Stop-CoursewareValidation 'field' $Field 'Expected a JSON object.'
    }
    $names = @($Value.PSObject.Properties.Name)
    foreach ($name in $Required) {
        if ($names -cnotcontains $name) { Stop-CoursewareValidation 'field' ($Field + '.' + $name) 'Required field is missing (names are case-sensitive).' }
    }
    foreach ($name in $names) {
        if (($Required + $Optional) -cnotcontains $name) { Stop-CoursewareValidation 'field' ($Field + '.' + $name) 'Unknown or inapplicable field; content would otherwise be discarded.' }
    }
}

function Assert-CoursewareText {
    param($Value, [int]$Maximum, [string]$Field, [switch]$AllowEmpty, [switch]$Multiline)
    if ($Value -isnot [string] -or $Value.Length -gt $Maximum -or ((-not $AllowEmpty) -and [string]::IsNullOrWhiteSpace($Value))) {
        Stop-CoursewareValidation 'text' $Field ('Expected text with at most {0} UTF-16 code units; empty allowed: {1}.' -f $Maximum,[bool]$AllowEmpty)
    }
    $pattern = '[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]'
    if (-not $Multiline) { $pattern = '[\x00-\x1F\x7F\u2028\u2029]' }
    if ($Value -match $pattern) { Stop-CoursewareValidation 'text' $Field 'Control characters or line breaks are not allowed here.' }
}

function Assert-CoursewareJson {
    param([string]$Json)
    if (-not $Json.TrimStart().StartsWith('{')) { Stop-CoursewareValidation 'field' '$' 'The lesson root must be an object.' }
    # ConvertFrom-Json can silently discard duplicate keys. Inspect tokens before conversion.
    $pattern = '"(?:[^"\\\x00-\x1F]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"|[{}\[\]:,]|true|false|null|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?'
    $tokens = [regex]::Matches($Json, $pattern)
    $stack = New-Object 'System.Collections.Generic.List[object]'
    $offset = 0
    for ($i = 0; $i -lt $tokens.Count; $i++) {
        $token = $tokens[$i]
        if ($Json.Substring($offset, $token.Index - $offset).Trim().Length -ne 0) { Stop-CoursewareValidation 'json' '$' 'Invalid JSON token or comment.' }
        $offset = $token.Index + $token.Length
        $value = $token.Value
        if ($value -eq '{' -or $value -eq '[') {
            if ($stack.Count -ge 32) { Stop-CoursewareValidation 'json' '$' 'JSON nesting exceeds 32 levels.' }
            $stack.Add([pscustomobject]@{kind=$value;keys=(New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase))})
        }
        elseif ($value -eq '}' -or $value -eq ']') {
            if ($stack.Count -eq 0 -or ($i -gt 0 -and $tokens[$i-1].Value -eq ',')) { Stop-CoursewareValidation 'json' '$' 'Unbalanced JSON or trailing comma.' }
            $stack.RemoveAt($stack.Count - 1)
        }
        elseif ($value.StartsWith('"') -and $i+1 -lt $tokens.Count -and $tokens[$i+1].Value -eq ':') {
            if ($stack.Count -eq 0 -or $stack[$stack.Count-1].kind -ne '{') { Stop-CoursewareValidation 'json' '$' 'Object key outside an object.' }
            $key = (ConvertFrom-Json -InputObject ('{"key":' + $value + '}') -ErrorAction Stop).key
            if (-not $stack[$stack.Count-1].keys.Add($key)) { Stop-CoursewareValidation 'json' '$' ('Duplicate JSON key: ' + $key) }
        }
    }
    if ($stack.Count -ne 0 -or $Json.Substring($offset).Trim().Length -ne 0) { Stop-CoursewareValidation 'json' '$' 'Incomplete JSON.' }
}

function Resolve-CoursewareAsset {
    param([string]$LessonDirectory, $RelativePath, [string[]]$Extensions, [string]$Field)
    if ($RelativePath -isnot [string] -or [string]::IsNullOrWhiteSpace($RelativePath) -or [IO.Path]::IsPathRooted($RelativePath) -or $RelativePath -match '[:<>"|?*\x00-\x1F]') {
        Stop-CoursewareValidation 'asset' $Field 'Asset must be a literal relative file path, never a URL, drive path, or UNC path.'
    }
    $parts = @($RelativePath -split '[\\/]')
    foreach ($part in $parts) {
        if ($part -in @('', '.', '..') -or $part -match '[. ]$' -or $part -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)') {
            Stop-CoursewareValidation 'asset' $Field 'Path traversal, ambiguous segments and device paths are forbidden.'
        }
    }
    $base = [IO.Path]::GetFullPath($LessonDirectory).TrimEnd([char[]]'\/')
    $full = [IO.Path]::GetFullPath((Join-Path $base ($parts -join [IO.Path]::DirectorySeparatorChar)))
    if (-not $full.StartsWith(($base + [IO.Path]::DirectorySeparatorChar), [StringComparison]::OrdinalIgnoreCase)) {
        Stop-CoursewareValidation 'asset' $Field 'Asset is outside the lesson folder.'
    }
    if ($Extensions -notcontains [IO.Path]::GetExtension($full).ToLowerInvariant()) { Stop-CoursewareValidation 'asset' $Field ('Allowed file extensions: ' + ($Extensions -join ', ')) }
    $current = $base
    foreach ($part in (@('') + $parts)) {
        if ($part) { $current = Join-Path $current $part }
        try { $item = Get-Item -LiteralPath $current -Force -ErrorAction Stop }
        catch { Stop-CoursewareValidation 'asset' $Field ('Asset path does not exist: ' + $RelativePath) }
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { Stop-CoursewareValidation 'asset' $Field 'Symlinks and junctions are not accepted as lesson assets.' }
    }
    if ($item.PSIsContainer -or $item.Length -eq 0) { Stop-CoursewareValidation 'asset' $Field 'Asset must be a nonempty file.' }
    return $full
}

function Test-CoursewareLesson {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$LessonPath)
    $fullPath = $LessonPath
    try {
        $fullPath = Resolve-CoursewareUserPath $LessonPath
        if (-not [IO.File]::Exists($fullPath)) { Stop-CoursewareValidation 'file' '$' 'Lesson JSON file does not exist.' }
        if ((Get-Item -LiteralPath $fullPath).Length -gt 2097152) { Stop-CoursewareValidation 'file' '$' 'Lesson JSON exceeds 2 MiB.' }
        $bytes = [IO.File]::ReadAllBytes($fullPath)
        $offset = 0
        if ($bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191) { $offset = 3 }
        try {
            $encoding = New-Object Text.UTF8Encoding($false, $true)
            $json = $encoding.GetString($bytes, $offset, $bytes.Length - $offset)
            Assert-CoursewareJson $json
            $lesson = ConvertFrom-Json -InputObject $json -ErrorAction Stop
        }
        catch {
            if ($_.Exception.Data.Contains('CoursewareCode')) { throw }
            Stop-CoursewareValidation 'json' '$' ('Invalid UTF-8 JSON: ' + $_.Exception.Message)
        }
        Assert-CoursewareFields $lesson @('title','slides') @() '$'
        Assert-CoursewareText $lesson.title 80 '$.title'
        if ($lesson.slides -isnot [array] -or $lesson.slides.Count -lt 1 -or $lesson.slides.Count -gt 200) { Stop-CoursewareValidation 'slides' '$.slides' 'Expected 1 to 200 slides in an array.' }
        $physical = $lesson.slides.Count
        for ($i = 0; $i -lt $lesson.slides.Count; $i++) {
            $s = $lesson.slides[$i]
            $field = '$.slides[' + $i + ']'
            Assert-CoursewareFields $s @('title','layout','sourcePages','notes','points') @('formula','image','model','rotationSteps') $field
            Assert-CoursewareText $s.title 40 ($field + '.title')
            if (@('title','concept','comparison','image','equation','model3d') -cnotcontains $s.layout) { Stop-CoursewareValidation 'layout' ($field + '.layout') 'Unknown layout (names are case-sensitive).' }
            $extras = @()
            switch ($s.layout) {
                'image' { $extras = @('image') }
                'equation' { $extras = @('formula') }
                'model3d' { $extras = @('model','rotationSteps') }
            }
            Assert-CoursewareFields $s @('title','layout','sourcePages','notes','points') $extras $field
            Assert-CoursewareText $s.notes 8000 ($field + '.notes') -AllowEmpty -Multiline
            if ($s.sourcePages -isnot [array] -or $s.sourcePages.Count -gt 20) { Stop-CoursewareValidation 'sourcePages' ($field + '.sourcePages') 'Expected an array with at most 20 source page numbers; [] means original material.' }
            foreach ($page in $s.sourcePages) {
                if (($page -isnot [int] -and $page -isnot [long]) -or $page -lt 1 -or $page -gt 100000) { Stop-CoursewareValidation 'sourcePages' ($field + '.sourcePages') 'Source page numbers must be integers from 1 to 100000.' }
            }
            if ($s.points -isnot [array] -or $s.points.Count -gt 3 -or ($s.layout -eq 'comparison' -and $s.points.Count -lt 2)) { Stop-CoursewareValidation 'points' ($field + '.points') 'Expected zero to three points, or two to three for comparison.' }
            foreach ($point in $s.points) { Assert-CoursewareText $point 48 ($field + '.points[]') }
            foreach ($required in @('image','formula','model')) {
                if ($extras -contains $required -and @($s.PSObject.Properties.Name) -cnotcontains $required) { Stop-CoursewareValidation 'field' ($field + '.' + $required) 'This layout requires this field.' }
            }
            if ($s.layout -eq 'equation') {
                Assert-CoursewareText $s.formula 72 ($field + '.formula') -Multiline
                if (@($s.formula -split '\r\n|\n|\r').Count -gt 3 -or $s.formula.Contains("`t")) { Stop-CoursewareValidation 'text' ($field + '.formula') 'Formula permits at most three lines and no tabs.' }
            }
            if ($s.layout -eq 'image') { [void](Resolve-CoursewareAsset (Split-Path -Parent $fullPath) $s.image @('.png','.jpg','.jpeg') ($field + '.image')) }
            if ($s.layout -eq 'model3d') {
                [void](Resolve-CoursewareAsset (Split-Path -Parent $fullPath) $s.model @('.glb') ($field + '.model'))
                if (@($s.PSObject.Properties.Name) -ccontains 'rotationSteps') {
                    if ($s.rotationSteps -isnot [array] -or $s.rotationSteps.Count -gt 12) { Stop-CoursewareValidation 'rotation' ($field + '.rotationSteps') 'Expected an array of zero to twelve absolute model poses.' }
                    foreach ($pose in $s.rotationSteps) {
                        Assert-CoursewareFields $pose @('x','y','z') @() ($field + '.rotationSteps[]')
                        foreach ($axis in @('x','y','z')) {
                            $angle = $pose.$axis
                            if (($angle -isnot [int] -and $angle -isnot [long] -and $angle -isnot [double] -and $angle -isnot [decimal]) -or [double]::IsNaN([double]$angle) -or [double]::IsInfinity([double]$angle) -or $angle -lt -360 -or $angle -gt 360) {
                                Stop-CoursewareValidation 'rotation' ($field + '.rotationSteps[].' + $axis) 'Angle must be a finite JSON number between -360 and 360 degrees.'
                            }
                        }
                    }
                    $physical += $s.rotationSteps.Count
                }
            }
        }
        if ($physical -gt 500) { Stop-CoursewareValidation 'slides' '$.slides' 'The lesson exceeds 500 physical slides after rotation steps.' }
        return [pscustomobject]@{valid=$true; lessonPath=$fullPath; topicCount=$lesson.slides.Count; physicalSlideCount=$physical; errors=@(); lesson=$lesson}
    }
    catch {
        $code = 'file'; $field = '$'
        if ($_.Exception.Data.Contains('CoursewareCode')) { $code = $_.Exception.Data['CoursewareCode']; $field = $_.Exception.Data['CoursewareField'] }
        return [pscustomobject]@{valid=$false; lessonPath=$fullPath; topicCount=0; physicalSlideCount=0; errors=@([pscustomobject]@{code=$code; path=$field; message=$_.Exception.Message}); lesson=$null}
    }
}

function Get-CoursewareOutputPaths {
    param([string]$LessonPath, [string]$OutputPath, [string]$PreviewDirectory)
    try {
        if ([string]::IsNullOrWhiteSpace($OutputPath)) { throw 'OutputPath is required.' }
        $inputFull = Resolve-CoursewareUserPath $LessonPath
        $outputFull = Resolve-CoursewareUserPath $OutputPath
        if ($outputFull -eq $inputFull) { throw 'OutputPath collides with the input lesson.' }
        if (Test-Path -LiteralPath $outputFull) { throw 'OutputPath already exists; overwriting is forbidden.' }
        if ([IO.Path]::GetExtension($outputFull) -ine '.pptx') { throw 'OutputPath must end in .pptx.' }
        if (-not [IO.Directory]::Exists([IO.Path]::GetDirectoryName($outputFull))) { throw 'The output parent directory must already exist.' }
        if ([IO.Path]::GetFileName($outputFull) -match '[:<>"|?*\x00-\x1F]|[. ]$') { throw 'Output filename is invalid.' }
        $previewFull = $null
        if ($PreviewDirectory) {
            $previewFull = (Resolve-CoursewareUserPath $PreviewDirectory).TrimEnd([char[]]'\/')
            if (Test-Path -LiteralPath $previewFull) { throw 'PreviewDirectory already exists; use a new directory.' }
            if ($previewFull -eq $outputFull -or $previewFull -eq $inputFull) { throw 'PreviewDirectory collides with an input or output file.' }
            if (-not [IO.Directory]::Exists([IO.Path]::GetDirectoryName($previewFull))) { throw 'The preview parent directory must already exist.' }
        }
        return [pscustomobject]@{outputPath=$outputFull;previewDirectory=$previewFull}
    }
    catch { Stop-CoursewareValidation 'output' '$.output' $_.Exception.Message }
}

function Assert-CoursewareOfficeExecutable {
    param([string]$Executable)
    if ($Executable -notmatch '(?i)\\Microsoft Office\\(?:root\\)?Office[0-9]+\\POWERPNT\.EXE$' -or -not [IO.File]::Exists($Executable)) {
        throw 'Microsoft desktop PowerPoint in a Microsoft Office installation path is required; WPS and other substitutes are unsupported.'
    }
    $info = [Diagnostics.FileVersionInfo]::GetVersionInfo($Executable)
    if ($info.CompanyName -notmatch '^Microsoft Corporation$' -or $info.ProductName -notmatch 'Microsoft') {
        throw 'The registered PowerPoint executable does not identify Microsoft as its publisher.'
    }
    return [pscustomobject]@{executable=$Executable;fileVersion=$info.FileVersion;productName=$info.ProductName;companyName=$info.CompanyName}
}

function Get-CoursewareOfficeRegistration {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Windows desktop Microsoft PowerPoint is required.' }
    $problems = New-Object 'System.Collections.Generic.List[string]'
    foreach ($view in @([Microsoft.Win32.RegistryView]::Registry64,[Microsoft.Win32.RegistryView]::Registry32)) {
        $hive=$null; $classKey=$null; $serverKey=$null
        try {
            $hive = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::ClassesRoot,$view)
            $classKey = $hive.OpenSubKey('PowerPoint.Application\CLSID',$false)
            if (-not $classKey) { continue }
            $classId = [string]$classKey.GetValue('')
            $serverKey = $hive.OpenSubKey(('CLSID\' + $classId + '\LocalServer32'),$false)
            if (-not $serverKey) { continue }
            $command = [Environment]::ExpandEnvironmentVariables([string]$serverKey.GetValue(''))
            $match = [regex]::Match($command,'(?i)^\s*(?:"(?<exe>[^"]+\.exe)"|(?<exe>.+?\.exe))(?:\s|$)')
            if (-not $match.Success) { throw 'Could not read the PowerPoint COM server executable.' }
            $identity = Assert-CoursewareOfficeExecutable $match.Groups['exe'].Value
            return [pscustomobject]@{progId='PowerPoint.Application';registryView=$view.ToString();executable=$identity.executable;fileVersion=$identity.fileVersion;productName=$identity.productName;companyName=$identity.companyName}
        }
        catch { $problems.Add($_.Exception.Message) }
        finally {
            if ($serverKey) { $serverKey.Dispose() }
            if ($classKey) { $classKey.Dispose() }
            if ($hive) { $hive.Dispose() }
        }
    }
    throw ('Microsoft PowerPoint COM registration was not found or is not supported. ' + ($problems -join ' '))
}

function Assert-CoursewarePowerPoint {
    param($Application)
    if ([string]$Application.Name -notmatch 'PowerPoint' -or [string]$Application.Name -match '(?i)WPS|Kingsoft') { throw 'The COM application is not Microsoft PowerPoint.' }
    $identity = Assert-CoursewareOfficeExecutable (Join-Path ([string]$Application.Path) 'POWERPNT.EXE')
    return [pscustomobject]@{name=[string]$Application.Name;version=[string]$Application.Version;executable=$identity.executable}
}

function Close-CoursewareOwnedPresentation {
    param($Presentation)
    if ($null -ne $Presentation) {
        $Presentation.Saved = -1
        $Presentation.Close()
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($Presentation)
    }
}

function Set-CoursewareClickTransition {
    param($Slide, [switch]$Morph)
    $transition = $Slide.SlideShowTransition
    $transition.AdvanceOnClick = -1
    $transition.AdvanceOnTime = 0
    $transition.AdvanceTime = 0
    if ($Morph) { $transition.EntryEffect = 3954; $transition.Duration = 1.3 }
    else { $transition.EntryEffect = 0 }
    if ($transition.AdvanceOnClick -ne -1 -or $transition.AdvanceOnTime -ne 0) { throw 'PowerPoint did not retain click-only slide advance.' }
    if ($Morph -and ($transition.EntryEffect -ne 3954 -or [math]::Abs($transition.Duration-1.3) -gt 0.01)) { throw 'This PowerPoint installation does not support the required Morph transition (3954).' }
}

function Fit-CoursewareModelFrame {
    param($Shape)
    $width=[double]$Shape.Width
    $height=[double]$Shape.Height
    if ($width -le 0 -or $height -le 0 -or [double]::IsNaN($width) -or [double]::IsNaN($height) -or [double]::IsInfinity($width) -or [double]::IsInfinity($height)) {
        throw 'PowerPoint returned invalid model bounds.'
    }
    # Native rotation can expand the shape bounds. Reframe the display after each pose.
    $scale=[math]::Min(552.0/$width,316.0/$height)
    $Shape.LockAspectRatio=-1
    $Shape.Width=[single]($width*$scale)
    $Shape.Height=[single]($height*$scale)
    $Shape.Left=[single](48+(552-[double]$Shape.Width)/2)
    $Shape.Top=[single](152+(316-[double]$Shape.Height)/2)
    if ($Shape.Left -lt 47.9 -or $Shape.Top -lt 151.9 -or ($Shape.Left+$Shape.Width) -gt 600.1 -or ($Shape.Top+$Shape.Height) -gt 468.1) {
        throw 'PowerPoint did not contain the model in the fixed display frame.'
    }
}

function Set-CoursewareModelPose {
    param($Shape, [double]$X, [double]$Y, [double]$Z)
    if ($Shape.Type -ne 30) { throw 'PowerPoint did not create a native 3D model (shape type 30).' }
    $Shape.Model3D.RotationX = $X
    $Shape.Model3D.RotationY = $Y
    $Shape.Model3D.RotationZ = $Z
    foreach ($axis in @('X','Y','Z')) {
        $expected = Get-Variable -Name $axis -ValueOnly
        $actual = [double]$Shape.Model3D.('Rotation' + $axis)
        $difference = (($actual - $expected) % 360 + 540) % 360 - 180
        if ([math]::Abs($difference) -gt 0.1) { throw ('PowerPoint did not retain model rotation ' + $axis + '.') }
    }
    Fit-CoursewareModelFrame $Shape
}

function Test-CoursewareModelCapabilities {
    param($Application, [string]$ModelPath)
    $probe = $null
    try {
        $probe = $Application.Presentations.Add(0)
        $probe.PageSetup.SlideWidth=960
        $probe.PageSetup.SlideHeight=540
        $slide = $probe.Slides.Add(1,12)
        $shape = $slide.Shapes.Add3DModel($ModelPath,0,-1,48,152,552,316)
        $shape.Name = '!!CoursewareModel'
        Set-CoursewareModelPose $shape 18 32 0
        $next = $slide.Duplicate().Item(1)
        Set-CoursewareModelPose ($next.Shapes.Item('!!CoursewareModel')) 18 122 0
        Set-CoursewareClickTransition $next -Morph
        return [pscustomobject]@{supported=$true;shapeType=30;transition=3954;duration=1.3;advanceOnClick=-1;advanceOnTime=0}
    }
    catch { throw ('Native 3D/Morph feature probe failed. No static substitute was generated. ' + $_.Exception.Message) }
    finally { Close-CoursewareOwnedPresentation $probe }
}

function Assert-CoursewareFonts {
    Add-Type -AssemblyName System.Drawing
    $fonts = New-Object Drawing.Text.InstalledFontCollection
    try {
        $names = @($fonts.Families | ForEach-Object {
            $_.Name
            $_.GetName(1033)
        })
        foreach ($required in @('Microsoft YaHei','Cambria')) {
            if ($names -notcontains $required) { throw ('Required font is missing: ' + $required + '. Install it through your normal Office/Windows setup before generating.') }
        }
    }
    finally { $fonts.Dispose() }
}

function Add-CoursewareText {
    param($Slide, [string]$Name, [string]$Text, [single]$Left, [single]$Top, [single]$Width, [single]$Height, [single]$Size=24, [string]$Font='Microsoft YaHei', [int]$Color=0x302C28, [switch]$Bold, [int]$Align=1)
    $shape = $Slide.Shapes.AddTextbox(1,$Left,$Top,$Width,$Height)
    $shape.Name = $Name
    $frame = $shape.TextFrame
    $frame.AutoSize = 0
    $frame.WordWrap = -1
    $frame.MarginLeft=0; $frame.MarginRight=0; $frame.MarginTop=0; $frame.MarginBottom=0
    $range = $frame.TextRange
    $range.Text = $Text
    $range.Font.Name = $Font
    $range.Font.NameFarEast = 'Microsoft YaHei'
    $range.Font.Size = $Size
    $range.Font.Color.RGB = $Color
    $range.Font.Bold = 0
    if ($Bold) { $range.Font.Bold = -1 }
    $range.ParagraphFormat.Alignment = $Align
    $range.ParagraphFormat.SpaceBefore = 0
    $range.ParagraphFormat.SpaceAfter = 0
    $range.ParagraphFormat.SpaceWithin = 1
    $range.ParagraphFormat.Bullet.Visible = 0
    if ($Text.Length -gt 0) {
        $boundWidth=[double]$range.BoundWidth
        $boundHeight=[double]$range.BoundHeight
        if ($boundHeight -gt $Height+1 -or $boundWidth -gt $Width+1) {
            throw ('Text overflow on slide {0}, {1}: BoundWidth={2:0.###} pt, BoundHeight={3:0.###} pt; textbox Width={4:0.###} pt, Height={5:0.###} pt. Shorten or split the content; it was not truncated.' -f $Slide.SlideIndex,$Name,$boundWidth,$boundHeight,$Width,$Height)
        }
    }
    return $shape
}

function Add-CoursewareRule {
    param($Slide, [single]$X1, [single]$Y1, [single]$X2, [single]$Y2, [int]$Color=0xD9D9D9)
    $rule = $Slide.Shapes.AddLine($X1,$Y1,$X2,$Y2)
    $rule.Line.ForeColor.RGB = $Color
    $rule.Line.Weight = 1
}

function Add-CoursewarePoints {
    param($Slide, [object[]]$Points, [single]$Left=48, [single]$Top=164, [single]$Width=864, [single]$Slot=96, [single]$Size=26)
    for ($p=0; $p -lt $Points.Count; $p++) {
        [void](Add-CoursewareText $Slide ('CoursewarePoint' + ($p+1)) $Points[$p] $Left ($Top+$p*$Slot) $Width ($Slot-12) $Size)
    }
}

function Set-CoursewareNotes {
    param($Slide, $Item, [int]$Topic, [int]$TopicCount, [int]$Pose=0)
    $sources = 'original material'
    if ($Item.sourcePages.Count) { $sources = $Item.sourcePages -join ', ' }
    $metadata = '[Courseware] Topic {0}/{1}. Source pages: {2}.' -f $Topic,$TopicCount,$sources
    if ($Item.layout -eq 'model3d') { $metadata += ' Model pose ' + $Pose + '. Absolute Office display orientation with proportional framing; not a mathematical sequence of world-axis rotations.' }
    $Slide.NotesPage.Shapes.Placeholders.Item(2).TextFrame.TextRange.Text = $Item.notes + "`r`n`r`n" + $metadata
}

function New-CoursewareSlide {
    param($Presentation, $Lesson, $Item, [int]$Topic, [string]$LessonDirectory)
    $slide = $Presentation.Slides.Add($Presentation.Slides.Count+1,12)
    $slide.FollowMasterBackground=0
    $slide.Background.Fill.Solid()
    $slide.Background.Fill.ForeColor.RGB=0xFFFFFF
    Set-CoursewareClickTransition $slide
    [void]$slide.Tags.Add('CoursewareTopic',[string]$Topic)
    [void]$slide.Tags.Add('CoursewareLayout',$Item.layout)
    $titleTop=32; $titleSize=32; $titleHeight=88
    if ($Item.layout -eq 'title') { $titleTop=86; $titleSize=36; $titleHeight=102 }
    [void](Add-CoursewareText $slide 'CoursewareTitle' $Item.title 48 $titleTop 864 $titleHeight $titleSize -Bold)
    if ($Item.layout -ne 'title') { Add-CoursewareRule $slide 48 132 912 132 }
    [void](Add-CoursewareText $slide 'CoursewareTopic' ('Topic {0} / {1}' -f $Topic,$Lesson.slides.Count) 48 502 180 24 12)
    $sourceLabel = 'Source: original material'
    if ($Item.sourcePages.Count) { $sourceLabel = 'Source pages: ' + ($Item.sourcePages -join ', ') }
    [void](Add-CoursewareText $slide 'CoursewareSources' $sourceLabel 240 499 672 30 10 -Color 0x707070 -Align 3)
    switch ($Item.layout) {
        'title' {
            [void](Add-CoursewareText $slide 'CoursewareCourseTitle' $Lesson.title 48 202 864 62 20 -Color 0x76791F)
            Add-CoursewarePoints $slide $Item.points 48 282 864 64 20
        }
        'concept' { Add-CoursewarePoints $slide $Item.points }
        'comparison' {
            Add-CoursewareRule $slide 480 168 480 366
            [void](Add-CoursewareText $slide 'CoursewarePoint1' $Item.points[0] 48 174 398 182 26)
            [void](Add-CoursewareText $slide 'CoursewarePoint2' $Item.points[1] 514 174 398 182 26)
            if ($Item.points.Count -eq 3) { [void](Add-CoursewareText $slide 'CoursewarePoint3' $Item.points[2] 48 402 864 76 24 -Color 0x76791F) }
        }
        'equation' {
            [void](Add-CoursewareText $slide 'CoursewareFormula' $Item.formula 68 160 824 126 28 'Cambria' -Color 0x76791F -Align 2)
            Add-CoursewarePoints $slide $Item.points 48 292 864 64 20
        }
        'image' {
            $asset = Resolve-CoursewareAsset $LessonDirectory $Item.image @('.png','.jpg','.jpeg') '$.image'
            $picture = $slide.Shapes.AddPicture($asset,0,-1,48,156,-1,-1)
            $picture.Name='CoursewareImage'
            $scale = [math]::Min(552.0/$picture.Width,310.0/$picture.Height)
            $width=$picture.Width*$scale; $height=$picture.Height*$scale
            $picture.LockAspectRatio=-1
            $picture.Width=$width
            $picture.Left=48+(552-$width)/2
            $picture.Top=156+(310-$height)/2
            Add-CoursewarePoints $slide $Item.points 640 158 272 106 18
        }
        'model3d' {
            $asset = Resolve-CoursewareAsset $LessonDirectory $Item.model @('.glb') '$.model'
            $model = $slide.Shapes.Add3DModel($asset,0,-1,48,152,552,316)
            $model.Name='!!CoursewareModel'
            Set-CoursewareModelPose $model 0 0 0
            Add-CoursewarePoints $slide $Item.points 640 158 272 106 18
        }
    }
    Set-CoursewareNotes $slide $Item $Topic $Lesson.slides.Count
    return $slide
}

function New-CoursewarePresentation {
    [CmdletBinding()]
    param([string]$LessonPath, [string]$OutputPath, [string]$PreviewDirectory)
    $validation = Test-CoursewareLesson $LessonPath
    if (-not $validation.valid) { throw ('Lesson validation failed: ' + (ConvertTo-Json -InputObject $validation.errors -Compress -Depth 5)) }
    $paths = Get-CoursewareOutputPaths $validation.lessonPath $OutputPath $PreviewDirectory
    $registration = Get-CoursewareOfficeRegistration
    Assert-CoursewareFonts
    $lesson = $validation.lesson
    $lessonDirectory = Split-Path -Parent $validation.lessonPath
    $app=$null; $deck=$null; $staging=$null; $previewStaging=$null
    $published=$false; $previewPublished=$false
    $featureProbe=$null
    try {
        # PowerPoint COM may return an existing singleton. Never Quit or change global settings.
        $app = New-Object -ComObject $registration.progId
        $identity = Assert-CoursewarePowerPoint $app
        $modelSlides = @($lesson.slides | Where-Object { $_.layout -eq 'model3d' })
        if ($modelSlides.Count) {
            $probePath = Resolve-CoursewareAsset $lessonDirectory $modelSlides[0].model @('.glb') '$.model'
            $featureProbe = Test-CoursewareModelCapabilities $app $probePath
        }
        $deck = $app.Presentations.Add(0)
        $deck.PageSetup.SlideWidth=960
        $deck.PageSetup.SlideHeight=540
        for ($i=0; $i -lt $lesson.slides.Count; $i++) {
            $item=$lesson.slides[$i]
            $slide = New-CoursewareSlide $deck $lesson $item ($i+1) $lessonDirectory
            if ($item.layout -eq 'model3d' -and @($item.PSObject.Properties.Name) -contains 'rotationSteps') {
                for ($p=0; $p -lt $item.rotationSteps.Count; $p++) {
                    $slide=$slide.Duplicate().Item(1)
                    $pose=$item.rotationSteps[$p]
                    Set-CoursewareModelPose ($slide.Shapes.Item('!!CoursewareModel')) $pose.x $pose.y $pose.z
                    Set-CoursewareClickTransition $slide -Morph
                    Set-CoursewareNotes $slide $item ($i+1) $lesson.slides.Count ($p+1)
                }
            }
        }
        if ($deck.Slides.Count -ne $validation.physicalSlideCount) { throw 'Generated physical slide count does not match the validated lesson.' }
        $staging=Join-Path ([IO.Path]::GetDirectoryName($paths.outputPath)) ('.courseware-' + [guid]::NewGuid().ToString('N'))
        [void][IO.Directory]::CreateDirectory($staging)
        $temporaryPptx=Join-Path $staging 'courseware.pptx'
        $deck.SaveAs($temporaryPptx,24)
        if (-not [IO.File]::Exists($temporaryPptx) -or (Get-Item -LiteralPath $temporaryPptx).Length -eq 0) { throw 'PowerPoint did not save the PPTX. Check Office activation and any prompts manually.' }
        if ($paths.previewDirectory) {
            $previewStaging=Join-Path ([IO.Path]::GetDirectoryName($paths.previewDirectory)) ('.courseware-preview-' + [guid]::NewGuid().ToString('N'))
            $temporaryPreview=$previewStaging
            [void][IO.Directory]::CreateDirectory($temporaryPreview)
            for ($n=1; $n -le $deck.Slides.Count; $n++) {
                $png=Join-Path $temporaryPreview ('slide-{0:000}.png' -f $n)
                $deck.Slides.Item($n).Export($png,'PNG',1600,900)
                if (-not [IO.File]::Exists($png) -or (Get-Item -LiteralPath $png).Length -eq 0) { throw ('PowerPoint preview export failed on physical slide ' + $n) }
            }
        }
        Close-CoursewareOwnedPresentation $deck
        $deck=$null
        # File.Move refuses an existing destination even if another process won a race.
        [IO.File]::Move($temporaryPptx,$paths.outputPath)
        $published=$true
        if ($paths.previewDirectory) { [IO.Directory]::Move($temporaryPreview,$paths.previewDirectory); $previewPublished=$true }
        return [pscustomobject]@{success=$true;outputPath=$paths.outputPath;previewDirectory=$paths.previewDirectory;topicCount=$validation.topicCount;physicalSlideCount=$validation.physicalSlideCount;powerPoint=$identity;modelProbe=$featureProbe;teacherEnvironmentStatus='pending teacher-side verification'}
    }
    catch {
        $message=$_.Exception.Message
        if ($published) { $message += ' The newly generated PPTX was retained at ' + $paths.outputPath + '.' }
        if ($staging -and [IO.Directory]::Exists($staging)) { $message += ' Diagnostic staging files were retained at ' + $staging + '.' }
        if ($previewStaging -and [IO.Directory]::Exists($previewStaging)) { $message += ' Preview staging files were retained at ' + $previewStaging + '.' }
        throw $message
    }
    finally {
        Close-CoursewareOwnedPresentation $deck
        if ($app) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app) }
        if ($staging -and $published -and (-not $paths.previewDirectory -or $previewPublished)) {
            # Only the unique directory created above is eligible for cleanup.
            $parent=[IO.Path]::GetDirectoryName($paths.outputPath)
            if ([IO.Path]::GetDirectoryName($staging) -eq $parent -and [IO.Path]::GetFileName($staging) -match '^\.courseware-[0-9a-f]{32}$') { Remove-Item -LiteralPath $staging -Recurse -Force }
        }
    }
}
