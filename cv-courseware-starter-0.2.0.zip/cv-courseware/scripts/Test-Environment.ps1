#requires -Version 5.1
[CmdletBinding()]
param([string]$ProbeModelPath)

$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Courseware.Core.ps1')
$app=$null
$report=[ordered]@{
    success=$false
    mode='read-only registration inspection'
    powerShellVersion=$PSVersionTable.PSVersion.ToString()
    office=$null
    comStatus='not tested'
    licenseStatus='not checked; any Office activation/privacy/security prompts require manual user action'
    model3d=$null
    teacherEnvironmentStatus='pending teacher-side verification'
    errors=@()
}
try {
    $report.office=Get-CoursewareOfficeRegistration
    Assert-CoursewareFonts
    if ($ProbeModelPath) {
        $modelFull=Resolve-CoursewareUserPath $ProbeModelPath
        if (-not [IO.File]::Exists($modelFull) -or [IO.Path]::GetExtension($modelFull) -ine '.glb') { throw 'ProbeModelPath must be an existing local GLB file.' }
        $report.mode='explicit native 3D/Morph probe in an owned unsaved presentation'
        $app=New-Object -ComObject $report.office.progId
        $report.office=Assert-CoursewarePowerPoint $app
        $report.model3d=Test-CoursewareModelCapabilities $app $modelFull
        $report.comStatus='probe succeeded; saving not tested'
    }
    $report.success=$true
}
catch { $report.errors=@($_.Exception.Message) }
finally {
    if ($app) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app) }
}
[pscustomobject]$report | ConvertTo-Json -Depth 8
if (-not $report.success) { exit 1 }
exit 0
