﻿#requires -Version 5.1
Add-Type -AssemblyName System.Numerics
Add-Type -AssemblyName System.Numerics.Vectors
Add-Type -AssemblyName System.Drawing

function Get-CvEulerNumeric([double]$AngleX,[double]$AngleY,[string]$Order){
    $x=[Numerics.Matrix4x4]::CreateRotationX([single]($AngleX*[math]::PI/180))
    $y=[Numerics.Matrix4x4]::CreateRotationY([single]($AngleY*[math]::PI/180))
    # System.Numerics uses row vectors: transpose the result for our column-vector display.
    if($Order -eq 'XY'){$m=[Numerics.Matrix4x4]::Multiply($x,$y)}else{$m=[Numerics.Matrix4x4]::Multiply($y,$x)}
    $v=[Numerics.Vector3]::Transform([Numerics.Vector3]::UnitZ,$m)
    [pscustomobject]@{matrixRows=@($m.M11,$m.M21,$m.M31,$m.M12,$m.M22,$m.M32,$m.M13,$m.M23,$m.M33);vector=@($v.X,$v.Y,$v.Z)}
}
function Export-CvEulerFigures {
    param([double]$AngleX,[double]$AngleY,[string]$OutputDirectory)
    if(Test-Path -LiteralPath $OutputDirectory){throw 'Figure directory already exists.'}
    [void][IO.Directory]::CreateDirectory($OutputDirectory)
    $state=[ordered]@{angleX=$AngleX;angleY=$AngleY;XY=(Get-CvEulerNumeric $AngleX $AngleY 'XY');YX=(Get-CvEulerNumeric $AngleX $AngleY 'YX')}
    [IO.File]::WriteAllText((Join-Path $OutputDirectory 'math-state.json'),($state|ConvertTo-Json -Depth 6),(New-Object Text.UTF8Encoding($false)))
    $font=New-Object Drawing.Font('Microsoft YaHei',20);$small=New-Object Drawing.Font('Microsoft YaHei',14)
    $brush=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(37,51,54))
    try {
        foreach($name in @('axes','order-comparison')){
            $bmp=New-Object Drawing.Bitmap(1200,640);$g=[Drawing.Graphics]::FromImage($bmp)
            try{
                $g.Clear([Drawing.Color]::White);$g.SmoothingMode=[Drawing.Drawing2D.SmoothingMode]::AntiAlias
                for($panel=0;$panel -lt 2;$panel++){
                    $ox=260+600*$panel;$oy=350
                    $title=if($name -eq 'axes'){if($panel -eq 0){'固定世界坐标系'}else{'方向向量 p = (0, 0, 1)'}}else{if($panel -eq 0){'先 X 后 Y'}else{'先 Y 后 X'}}
                    $g.DrawString($title,$font,$brush,[single](45+600*$panel),[single]35)
                    foreach($axis in @(@('X',1,0,0,205,63,72),@('Y',0,1,0,35,130,90),@('Z',0,0,1,38,111,206))){
                        $pen=New-Object Drawing.Pen([Drawing.Color]::FromArgb($axis[4],$axis[5],$axis[6]),3)
                        try{$pen.EndCap=[Drawing.Drawing2D.LineCap]::ArrowAnchor;$sx=$ox+150*$axis[1]-110*$axis[3];$sy=$oy-175*$axis[2]+65*$axis[3]+38*$axis[1];$g.DrawLine($pen,[single]$ox,[single]$oy,[single]$sx,[single]$sy);$g.DrawString($axis[0],$font,$brush,[single]($sx+8),[single]($sy-15))}finally{$pen.Dispose()}
                    }
                    if($name -eq 'order-comparison'){
                        $v=if($panel -eq 0){$state.XY.vector}else{$state.YX.vector}
                        $pen=New-Object Drawing.Pen([Drawing.Color]::FromArgb(15,108,110),7)
                        try{$pen.EndCap=[Drawing.Drawing2D.LineCap]::ArrowAnchor;$g.DrawLine($pen,[single]$ox,[single]$oy,[single]($ox+150*$v[0]-110*$v[2]),[single]($oy-175*$v[1]+65*$v[2]+38*$v[0]))}finally{$pen.Dispose()}
                        $values=@($v|ForEach-Object{if([math]::Abs($_) -lt .0005){'0'}else{([math]::Round($_,3)).ToString([Globalization.CultureInfo]::InvariantCulture)}})
                        $g.DrawString(('R p = ('+($values -join ', ')+')'),$font,$brush,[single](45+600*$panel),[single]535)
                    }
                }
                $caption=if($name -eq 'axes'){'右手系 / 主动旋转 / 列向量 / 固定世界轴'}else{"X = $AngleX deg, Y = $AngleY deg | p = (0, 0, 1)"}
                $g.DrawString($caption,$small,$brush,[single]45,[single]590)
                $bmp.Save((Join-Path $OutputDirectory ($name+'.png')),[Drawing.Imaging.ImageFormat]::Png)
            }finally{$g.Dispose();$bmp.Dispose()}
        }
    }finally{$font.Dispose();$small.Dispose();$brush.Dispose()}
    [pscustomobject]@{axes=(Join-Path $OutputDirectory 'axes.png');comparison=(Join-Path $OutputDirectory 'order-comparison.png');state=$state}
}
