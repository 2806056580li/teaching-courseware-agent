#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$LessonPath,
    [Parameter(Mandatory=$true)][string]$OutputPath,
    [string]$PreviewDirectory
)

$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Courseware.Core.ps1')
try {
    New-CoursewarePresentation -LessonPath $LessonPath -OutputPath $OutputPath -PreviewDirectory $PreviewDirectory | ConvertTo-Json -Depth 8
    exit 0
}
catch {
    [pscustomobject]@{success=$false;error=$_.Exception.Message} | ConvertTo-Json -Depth 5
    exit 1
}
