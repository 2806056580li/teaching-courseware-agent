﻿#requires -Version 5.1
param([Parameter(Mandatory=$true)][string]$PackPath,[Parameter(Mandatory=$true)][string]$ResourceDirectory,[Parameter(Mandatory=$true)][string]$OutputDirectory,[switch]$IncludePowerPoint)
$ErrorActionPreference='Stop'
try{. (Join-Path $PSScriptRoot 'LessonPack.Export.ps1');New-CvLessonPackBundle $PackPath $ResourceDirectory $OutputDirectory -IncludePowerPoint:$IncludePowerPoint|ConvertTo-Json -Depth 8;exit 0}
catch{[pscustomobject]@{success=$false;error=$_.Exception.Message}|ConvertTo-Json -Depth 4;exit 1}
