# 兼容性与边界

## 首版目标

Windows 10/11、Windows PowerShell 5.1 或 PowerShell 7、已安装且获许可的 Microsoft PowerPoint 桌面版。无需 Node、Python、Codex 专用运行时或付费模型 API。操作系统和 Office 的支持期限由微软决定；请使用仍受支持的产品版本。

`Test-Environment.ps1` 检查 Office 身份和能力，不绕过许可、登录、保护视图或宏安全设置。激活和弹窗由教师自行处理。WPS 不能当作微软 Office COM 的替代品；网页 PowerPoint、Mac 和手机端不在本版原生三维生成器支持范围内。

## 三种效果不是一回事

| 效果 | 实现 | 本版状态 |
|---|---|---|
| 编辑时自由旋转 | 原生 GLB 对象中央三维控件 | 支持，仍需目标 Office 实测 |
| 放映时点击逐步旋转 | 同一原生对象的多页姿态 + Morph | 支持；每步停止等待下一次点击 |
| 放映时随鼠标任意拖转 | 交互查看器/加载项等额外机制 | 未实现，不作承诺 |

Morph 会增加物理页数，不自动推进。不同 Office 渲染和转场支持可能不同；若目标电脑不支持，保留静态角度页或视频作为明确标记的回退，不能声称仍有自由交互。

六种固定版式生成的文字与图形可编辑，图片是栅格图，模型为原生 3D。公式使用普通可编辑数学文本；复杂排版可经教师认可用公式图片，但不是本版自动 LaTeX 转换功能。程序不读取 PPT/PDF 内容，读取、OCR 和学科推理属于宿主 Agent 的能力。

## 已验证与未验证

开发验证包括 PowerShell 5.1/7、Microsoft PowerPoint 16 COM、原生类型30模型、点击转场和预览。发布附带测试结果单独说明确切范围。WorkBuddy 支持 Skill 不代表其文件读取、脚本执行、PowerPoint 自动化都已经验证，首次必须在老师电脑完成一次示例验收。

参考：[微软三维模型说明](https://support.microsoft.com/en-us/office/graphics-visuals/get-creative-with-3d-models)、[Morph 说明](https://support.microsoft.com/en-us/powerpoint/training/use-the-morph-transition-in-powerpoint)、[WorkBuddy Skill 文档](https://open.workbuddy.cn/en/docs/skill)。
