# Portable Lesson Format

This contract is shared by `Test-Lesson.ps1` and `Build-Courseware.ps1`.
It requires Windows PowerShell 5.1 or PowerShell 7 on Windows and native
Microsoft desktop PowerPoint for generation. No Python, Codex runtime,
PowerPoint add-in, third-party generator, or paid API is required.
Teacher-side WorkBuddy compatibility remains **pending teacher-side verification**.

## JSON Contract

Use strict UTF-8 JSON, with or without a UTF-8 BOM, up to 2 MiB. Field names
and layout names are case-sensitive. Unknown fields, duplicate keys (including
escaped or differently cased duplicates), comments, and trailing commas are
rejected. No field is silently discarded. String limits count UTF-16 code units,
including whitespace; supplementary characters use two units. Shorter text may
still fail the measured PowerPoint overflow check with a particular font.

Root object fields (both required; no other fields):

| Field | Type | Constraint |
| --- | --- | --- |
| `title` | string | Nonblank, single line, at most 80 units |
| `slides` | array of objects | 1 to 200 logical topics; at most 500 physical slides after poses |

Every slide requires all five common fields:

| Field | Type | Constraint |
| --- | --- | --- |
| `title` | string | Nonblank, single line, at most 40 units |
| `layout` | string | Exactly `title`, `concept`, `comparison`, `image`, `equation`, or `model3d` |
| `sourcePages` | integer array | 0 to 20 page numbers, each 1 to 100000; `[]` declares original material |
| `notes` | string | 0 to 8000 units; line breaks and tabs permitted; other control characters rejected |
| `points` | string array | 0 to 3 nonblank, single-line strings, each at most 48 units; comparison requires 2 or 3 |

Coordinates, fonts, sizes, timing, links, and arbitrary extra fields are not
accepted. Split long content into additional topics before generating.

Layout-specific fields:

| Layout | Additional fields | Result |
| --- | --- | --- |
| `title` | None | Large slide title, course title, and all points |
| `concept` | None | Vertically arranged points |
| `comparison` | None | Point 1 left, point 2 right, optional point 3 below both |
| `image` | Required `image` string | Embedded PNG/JPG/JPEG, aspect ratio preserved, points on the right |
| `equation` | Required `formula` string | Editable Cambria text, followed by all points |
| `model3d` | Required `model` string; optional `rotationSteps` array | Embedded GLB, points on the right, additional native model poses |

Fields belonging to another layout are errors, even when empty. Explicit `null`
does not stand in for an omitted optional field. `formula` is nonblank, at most
72 units and 3 lines, with no tabs or other control characters. It is literal
editable text, not LaTeX, MathML, an equation parser, or an Office math object.
Use the teacher-approved notation and inspect the preview. No mathematical
claims are inferred from the formula string.

`image` and `model` are file paths relative to the JSON file's folder. Assets
must be nonempty existing files in that folder or its subfolders. Absolute,
drive-relative, UNC, URL, alternate-stream, wildcard, device, `.` and `..`
paths are rejected. Symlinks/junctions on the lesson folder or asset path are
rejected. Use `/` or escaped backslashes as separators. Filename decoding or
URL fetching is never performed. The input validator checks paths and types;
PowerPoint must still successfully decode the media during generation.

## Native 3D Poses

`rotationSteps` contains 0 to 12 objects. Each object has exactly numeric `x`,
`y`, `z` fields. Each value must be finite and in [-360, 360], in degrees.
Omitting the array or supplying `[]` yields only the base slide.

```json
{
  "title": "Coordinate frames",
  "slides": [
    {
      "title": "Model orientation",
      "layout": "model3d",
      "sourcePages": [7, 8],
      "notes": "Record the model source and license here. Explain the frame convention.",
      "points": ["Compare the model orientations."],
      "model": "assets/model.glb",
      "rotationSteps": [
        { "x": 18, "y": 45, "z": 0 },
        { "x": 18, "y": 90, "z": 0 }
      ]
    }
  ]
}
```

The first physical slide has absolute display rotation (0, 0, 0). Each pose
duplicates the preceding slide and applies `Model3D.RotationX/Y/Z` to a native
type-30 shape named `!!CoursewareModel`. These are absolute Office display
orientations, not deltas or mathematical world-axis rotation operations.
After every pose, including the base slide and the feature probe, the actual
model bounds are scaled proportionally with `LockAspectRatio=-1` and centered
inside Left=48, Top=152, Width=552, Height=316 pt. This contains the expanded
bounds caused by native rotation above the footer and below the title rule.
The per-pose fitting is display composition, not a fixed physical scale or an
exact world-axis rotation demonstration.
Each added pose slide uses `EntryEffect=3954`, `Duration=1.3`.
Every slide uses `AdvanceOnClick=-1`, `AdvanceOnTime=0`. Each click advances
once and waits. This does not implement drag-to-rotate during slideshow.

For the example above, `topicCount=1`, `physicalSlideCount=3`. The footer stays
`Topic 1 / 1` across all three physical slides. Source pages and original
speaker notes are preserved; metadata is appended to the notes.

Before generating any model lesson, the builder explicitly probes embedding,
type 30, all rotation properties, duplication, and Morph in its own unsaved
presentation. Unsupported behavior fails without substituting a picture.
GLB calls use `Add3DModel(path, 0, -1, ...)` to embed the asset.

For an image page, use the same common fields with `layout: "image"` and
`image: "assets/diagram.png"`. The bundled `templates/example.json` is an
offline four-topic Chinese example requiring no downloaded assets. It covers
title, concept, comparison, and equation; the image and model layouts require
the user's actual local assets.

## Commands

Run these from the installed `cv-courseware` directory in a PowerShell session
where local scripts are permitted. The scripts do not alter execution policy,
Office activation, privacy, security, add-ins, installations, or settings.

```powershell
.\scripts\Test-Lesson.ps1 -LessonPath .\templates\example.json
.\scripts\Test-Environment.ps1
.\scripts\Test-Environment.ps1 -ProbeModelPath C:\Lessons\assets\model.glb
.\scripts\Build-Courseware.ps1 -LessonPath C:\Lessons\lesson.json -OutputPath C:\Lessons\lesson-new.pptx -PreviewDirectory C:\Lessons\preview-new
```

`Test-Lesson` returns JSON with `valid`, `lessonPath`, `topicCount`,
`physicalSlideCount`, and `errors` (objects with `code`, `path`, `message`).
Exit 0 means valid input; exit 1 means invalid. It uses no Office COM.

`Test-Environment` without arguments reads registration, Microsoft Office
executable metadata, and font availability only. It starts no COM application
and returns `model3d: null`, `comStatus: "not tested"`. Exit 0 means these
prerequisites passed, not that licensing, saving, or 3D has been verified.
Only explicit `-ProbeModelPath` invokes COM with a local GLB. The probe creates
and closes only its own unsaved presentation, never saving a file. License
status is not inferred from a version or a successful probe. Any authorization
or privacy dialog is for the user to handle manually.

`Build-Courseware` validates before opening COM, enforces a Microsoft Office
PowerPoint executable (WPS is rejected), uses 960 x 540 pt white slides, and
saves PPTX format 24. Body text uses Microsoft YaHei; formula Latin text uses
Cambria and East Asian text uses Microsoft YaHei through `Font.NameFarEast`.
Both fonts must already be installed. Native text, rules, and models remain
editable. Images are embedded with no external file link. The generator does
not create axis annotations in arbitrary models; author those in the asset,
using X red / Y green / Z blue as appropriate.

`OutputPath` must be a new `.pptx`, different from the input. Its parent must
already exist. Optional `PreviewDirectory` must also be new with an existing
parent. Relative command-line paths follow the current PowerShell location,
including `Set-Location` and `Push-Location`, rather than the process startup
directory. Relative asset paths inside JSON still follow the lesson folder.
The preview directory receives `slide-001.png`, etc., for every physical slide at
1600 x 900. Existing output files and preview directories are rejected before
COM. Final publication uses a no-overwrite file move, including race protection.
On error, any already published new PPTX and staging files are retained and
identified in the error for inspection; nothing existing is deleted.

The builder returns JSON with `success`, `outputPath`, `previewDirectory`,
`topicCount`, `physicalSlideCount`, `powerPoint`, `modelProbe`, and
`teacherEnvironmentStatus`; failures return `success: false` and `error`.
Exit 0 means generation succeeded; exit 1 means a failure. Text that exceeds
its measured fixed textbox bounds fails without truncation or font shrinking.

PowerPoint COM may share an already running singleton even after creating a
fresh COM wrapper. These scripts never call `Quit`, close unrelated documents,
change global alerts/security settings, or manipulate user windows. Run only
one Office automation job at a time. A PowerPoint process may remain open after
generation or a feature probe; this is intentional to protect user documents.

## Verification

From the repository root:

```powershell
.\tests\test-input.ps1 -LogPath C:\Lessons\input-test-results.json
.\tests\test-build.ps1
.\tests\test-build.ps1 -RunPowerPoint -ModelPath C:\Lessons\assets\licensed.glb -ArtifactsDirectory C:\Lessons\acceptance-new
```

Input tests use no COM and can run under both PowerShell versions. The build
test without `-RunPowerPoint` reports skipped and does not touch Office. Run
the explicit build test only after other Office automation finishes. Omitting
`-ModelPath` tests the five non-model layouts and explicitly skips 3D/Morph.
With a model it tests six topics/eight physical slides, click-only transitions,
saved poses, editable text, notes, embedded media, no external relationships,
previews, no overwrite, and survival of a preexisting presentation. Test
artifacts and `test-results.json` are retained in the reported directory.
Rendered previews and actual slideshow clicks still require visual inspection.
