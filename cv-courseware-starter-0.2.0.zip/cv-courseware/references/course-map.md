# 课程方向与资源选择

这是按已有七章方向整理的精选入口，不是完整教材、完整依赖环境、训练数据集或所有模型库的镜像。下载条目的版本、SHA256、字节数与许可见 `resource-catalog.json`。

| 章节方向 | Topics | 主要来源 | 最有用的课件表现 |
|---|---|---|---|
| 绪论 | features, calibration, stereo | OpenCV、Open3D | 输入图像、任务输出和应用对照；不先堆数学 |
| 空间几何变换 | geometry | Khronos glTF、OpenCV | 坐标系、变换前后、原生3D角度序列 |
| 视觉图像特征提取 | features | OpenCV 官方教程/示例 | 边缘、角点、描述子、匹配的分步图 |
| 相机成像与标定 | calibration | OpenCV calib3d、ArUco | 针孔示意、棋盘角点、重投影、畸变前后 |
| 立体视觉重建 | stereo | OpenCV、Open3D | 极线、视差、点云；区分二维示意和真实重建 |
| 结构光三维视觉 | structured-light | OpenCV contrib structured_light/phase_unwrapping | Gray码/相移编码、投影-相机几何 |
| 机器视觉的纹理设计 | texture | OpenCV Gabor、ccalib、ArUco/ChArUco | 自然/随机/编码纹理与匹配稳定性 |
| 深度学习补充 | deep-learning | PyTorch、TorchVision 官方文档/示例 | 仅作为补充阅读，不冒充已收到的独立授课章节 |

`common` 是随任意主题一起保留的授权文件，不是单独授课内容。`geometry` 的 BoxVertexColors 适合方向对照，ToyCar 适合视角演示。复杂模型应控制文件大小、留白和相机取景；医学或工程教学的准确性不能由通用模型替代。

下载下来的教学代码供 Agent 理解/改编图解，不会自动安装 OpenCV/Open3D/PyTorch，也不自动执行 `pip install`、远程脚本或外部数据下载。确实需要实验时，先说明新依赖、数据许可和计算成本，再按老师需求另行准备。
