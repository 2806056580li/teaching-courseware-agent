# 统一备课包 v1

备课包是 JSON 内容真源，Markdown 是审阅输出。仅本节 `euler-order` 提供固定互动组件；其他课题继续使用 `lesson-format.md`，不要把本组件声称为通用仿真引擎。

直接从 `templates/euler/lesson-pack.json` 复制新文件，保留字段结构。UTF-8，不超过 2 MiB，拒绝未知字段、重复键、空必填文本、超限值及脚本标签。所有 ID 为小写字母开头、最多64位的小写字母/数字/连字符；跨条目的引用必须存在且不重复。

## 字段

| 字段 | 约定 |
| --- | --- |
| schemaVersion | 整数 1 |
| lessonId / revision | 稳定课程标识 / 数字 major.minor.patch；内容改变应更新 revision |
| title / audience | 最多80 / 160个 UTF-16单元 |
| durationMinutes | 5到180的整数 |
| language / reviewStatus | zh-CN / draft或teacher-approved；只有教师真实确认才写后者 |
| sources | 0到20条，每条 id,title,citation,pages,shareWithStudents；后者必须为布尔值，公开引用不能含本机路径 |
| objectives | 1到6条，每条 id,text,prerequisites；text最多200，prerequisites最多6条、每条120 |
| concepts | 1到12条：id,title,intuitive,standard,advanced,misconceptions,objectiveIds,sourceIds；title80，每层解释1200，误解最多6条、每条200 |
| activity | kind=euler-order，angleX/angleY为-180到180的有限数字；modelResourceId沿用示例中的ToyCar ID |
| exercises | 5到12条：id,kind,prompt,hints,objectiveIds；三条diagnostic，至少一条guided和transfer；prompt1000，提示最多3条、每条400；不允许answer字段 |
| units | 六条固定顺序goals,axes,order,matrix,observation,summary；每条id,kind,title,points,notes,objectiveIds,sourceIds；title40，points最多3条、每条48，notes8000 |
| teacherGuide | 包内相对路径的Markdown文件，最多256 KiB；无绝对路径、..、链接或目录联接 |

sources 的 citation 只作为资料引用，不执行、不自动下载。pages最多20个正整数。概念、练习和教学单元的objectiveIds至少一项，sourceIds可为空表示原创内容。重复ID或悬空引用会停止生成。

`notes` 加上自动附加的课程ID、版本、目标及来源引用后，总长度仍须不超过8000。校验器会提前报告超限，不静默截断；较长教学说明请放入 `teacherGuide`。

## 调用

在 Skill 目录中运行，示例假设离线包的 resources 与 cv-courseware 同级：

```powershell
& .\scripts\Test-LessonPack.ps1 -PackPath .\templates\euler\lesson-pack.json -ResourceDirectory ..\resources
& .\scripts\Build-LessonPack.ps1 -PackPath .\templates\euler\lesson-pack.json -ResourceDirectory ..\resources -OutputDirectory ..\euler-output
```

输出父目录必须存在，输出目录必须不存在。无需PowerPoint即可生成HTML、文字学习包和PPT输入。加 `-IncludePowerPoint` 才会生成原生PPTX和预览，届时需要Windows桌面Microsoft PowerPoint。脚本不会修改执行策略或授权设置。

返回JSON与退出码：成功0；失败1并说明原因。失败保留诊断临时目录，不把半成品目录标记成成功。输出不覆盖原文件。

## 输出边界

- `student/`：可单独发给学生；含自包含HTML、JSON/Markdown内容、START.txt、学习记录模板与许可证。
- `teacher/`：教案和参考答案；不要一起发给学生。
- `ppt/`：现有六版式输入、内嵌素材、科学图；选择PPT生成时另含PPTX与预览。
- `build-report.json`：版本、输入哈希和输出哈希。用于识别旧材料，不是教师认可或学生掌握证明。

学生JSON采用白名单，没有教师guide和单元notes。教师仍需审查自己填写的学生可见定义、题干和提示，白名单不能自动理解文本中是否误填了答案。

## 数学与显示

右手系、列向量、主动旋转、固定世界轴。XY表示先X后Y，R=Ry Rx；YX表示R=Rx Ry。测试向量为(0,0,1)，步骤0/1/2。页面拖拽只改变相机，输入角度改变模型计算。鼠标观察与数学旋转分离。

PPT原生模型页用于观察姿态，不把Office显示角度当作世界轴计算证据。科学图由同一初始角度生成，HTML可继续探索其他角度。图形能力失效时的备用图只表示初始设定，页面仍显示当前数值计算。
