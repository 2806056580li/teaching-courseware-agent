---
name: cv-courseware
description: Use when a teacher wants to improve computer-vision slides while preserving their outline, create native PowerPoint 3D views, or prepare an offline Euler-rotation lesson and student-agent learning pack. 适用于计算机视觉课件与空间旋转互动教学。
---

# 计算机视觉课件

保留老师的教学主线，把页面、图解和素材做清楚。固定脚本负责版式和 PowerPoint 原生对象；Agent 负责读懂资料、选择素材和核对教学内容。不含在线作业系统、自动评分或学习效果承诺。

## 备课包与互动样板

需要欧拉角旋转顺序的互动演示时，读取 [lesson-pack-format.md](references/lesson-pack-format.md)，从 `templates/euler/lesson-pack.json` 建立新版本。先确认教学目标和内容，再调用 `Test-LessonPack.ps1` 与 `Build-LessonPack.ps1`。不要把固定Euler组件改名后冒充其他仿真。

默认生成无需Office的离线HTML、文字学习包和PPT输入；显式 `-IncludePowerPoint` 才生成PPTX。老师只需浏览器查看HTML，不需要Node/Python。学生只收 `student` 目录，教师答案留在 `teacher`。随包 `START.txt` 是给学生Agent的入口；规则见 [student-tutoring.md](references/student-tutoring.md)。

核对模型拖拽只改变视角，角度和步骤才改变数学旋转；备用图仅代表初始角度。发给老师前按 [teacher-acceptance.md](references/teacher-acceptance.md) 标明已测项和待实机验证项。

## 开始

- 已有讲义、课程方向或要求就直接使用，不重复询问。只补问缺失且影响制作的信息：本讲题目、学生基础、课时、必须保留的内容。
- 先阅读原始页，建立“原稿页码 -> 新页 -> 保留/移入备注/需教师确认”表。扫描件公式必须看原图，不能仅凭 OCR。
- 读取 [lesson-format.md](references/lesson-format.md) 及 `templates/example.json`。不要猜 JSON 字段，不自由改变生成器坐标。
- Windows 桌面 PowerPoint 是原生三维的目标环境；先运行 `scripts/Test-Environment.ps1`，检查返回结果。详见 [compatibility.md](references/compatibility.md)。无可用 Office 时交付已校验的内容和缺失条件，不声称已生成或已实测 PPT。

## 选择资源

按 [course-map.md](references/course-map.md) 选择主题。`references/resource-catalog.json` 是固定版本、哈希和授权记录，不是联网搜索结果。下载代码只供阅读，不执行上游示例，也不因此下载数据集或权重。

```powershell
# 在 Skill 文件夹执行；课件和缓存放到自己的新工作目录。
& .\scripts\Get-Resources.ps1 -Destination 'D:\LessonWork\resources' -Topics features
& .\scripts\Get-Resources.ps1 -Destination 'D:\LessonWork\resources' -Topics features -VerifyOnly
```

`-Topics` 省略时获取整个精选目录；`common` 许可证会随主题获取。图片或模型复制到课件 JSON 的子目录，再填相对路径。下载失败、哈希错误或素材授权不清楚时停止使用该条目，不能悄悄换成不明素材。网络受限时可用老师收到的离线资源包。

## 制作

1. 先确定页纲。每页一个重点，最多三个短要点；图片/模型右侧窄栏优先每条约12个汉字，长推导和讲解移入 `notes`。JSON 字数上限不代表任何字体下都能放下，原生溢出检查报错时缩短或拆页，不能截断文字或删掉必要数学条件。参照 [teaching-checklist.md](references/teaching-checklist.md)。
2. 生成 `lesson.json`，采用 `title/concept/comparison/image/equation/model3d` 六种版式。图像须有教学目的和来源，示意图不冒充实验数据。公式是可编辑普通文本，不是 LaTeX 排版器。
3. 校验，修正错误，然后生成到不存在的新 `.pptx` 文件：

```powershell
& .\scripts\Test-Lesson.ps1 -LessonPath 'D:\LessonWork\lesson.json'
& .\scripts\Build-Courseware.ps1 -LessonPath 'D:\LessonWork\lesson.json' -OutputPath 'D:\LessonWork\lesson-v1.pptx' -PreviewDirectory 'D:\LessonWork\preview-v1'
```

4. `model3d` 必须引用真实 GLB。`rotationSteps` 是绝对姿态列表，每项新增一个物理页，Morph 在点击后转到该姿态并停住。它不是放映时鼠标自由拖动；自由旋转在编辑视图中进行。不能把静态图称为原生模型。
5. 逐页打开预览，检查文字、科学图、留白和重叠。修 JSON 后输出新版本；最多自行修复三轮，同一故障仍存在就说明具体阻碍，不关闭用户其他文稿或无限重试。
6. 在实际 PowerPoint 打开放映，检查模型、点击停留、字体及图片。无法进行的测试明确标记“未实测”。生成器的结构检查不能替代目视检查和教师学术审阅。

## 交付

交付 PPTX、JSON、素材来源和待教师确认项。报告内容页与物理页两个数量，说明三维操作方式及实际测试环境。不上传老师课件、学生资料或生成文件；上传、共享或修改仓库权限需要用户明确要求。原文件保持不动。

工具使版式和原生对象更稳定，但不会把所有 Agent 的学科理解变成一样强。首次给某个 Agent 或 Office 版本使用时，先通过通用示例，再做三页教师样板；尚未测试的 WorkBuddy 环境不能标记为已兼容。
