﻿#requires -Version 5.1
param([string]$ResourceDirectory='.build/release-cache/resources',[switch]$IncludePowerPoint)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$skill=Join-Path $root 'skills/cv-courseware';if(-not(Test-Path $skill)){$skill=Join-Path $root 'cv-courseware'}
$module=Join-Path $skill 'scripts/LessonPack.Export.ps1'
if(-not(Test-Path $module)){throw 'RED: LessonPack.Export.ps1 has not been implemented'}
. $module
$cache=Resolve-CoursewareUserPath $ResourceDirectory
$fixture=Join-Path ([IO.Path]::GetTempPath()) ('cv-export-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($fixture)
Copy-Item -LiteralPath (Join-Path $skill 'templates/euler') -Destination (Join-Path $fixture 'input') -Recurse
$inputPath=Join-Path $fixture 'input/lesson-pack.json'
$p=Get-Content $inputPath -Raw -Encoding UTF8|ConvertFrom-Json
$p.units[0].notes='TEACHER_SENTINEL_NOT_STUDENT'
$p.sources+=@([pscustomobject]@{id='private';title='TEACHER_SENTINEL_NOT_STUDENT';citation='private guide';pages=@();shareWithStudents=$false})
[IO.File]::WriteAllText($inputPath,($p|ConvertTo-Json -Depth 20),(New-Object Text.UTF8Encoding($false)))
[IO.File]::AppendAllText((Join-Path $fixture 'input/teacher-guide.md'),"`nTEACHER_SENTINEL_NOT_STUDENT")
$out=Join-Path $fixture 'output with spaces'
$r=New-CvLessonPackBundle -PackPath $inputPath -ResourceDirectory $cache -OutputDirectory $out -IncludePowerPoint:$IncludePowerPoint
if(-not$r.success){throw 'Build failed'}
$passed=1
foreach($name in @('teacher/lesson-plan.md','teacher/teacher-guide.md','student/learning-pack.json','student/learning-pack.md','student/START.txt','student/learning-record.md','student/lesson.html','ppt/lesson.json','build-report.json')){
    if(-not(Test-Path (Join-Path $out $name))){throw "Missing output: $name"};$passed++
}
$student=Get-Content (Join-Path $out 'student/learning-pack.json') -Raw -Encoding UTF8
if($student.Contains('TEACHER_SENTINEL_NOT_STUDENT')){throw 'Teacher JSON leak'};$passed++
$html=Get-Content (Join-Path $out 'student/lesson.html') -Raw -Encoding UTF8
$match=[regex]::Match($html,'<script id="lesson-data" type="application/octet-stream">([^<]+)</script>')
if(-not$match.Success){throw 'Missing payload'}
$decoded=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($match.Groups[1].Value))
if($decoded.Contains('TEACHER_SENTINEL_NOT_STUDENT') -or $decoded.Contains($fixture)){throw 'Teacher payload leak'};$passed++
foreach($file in Get-ChildItem (Join-Path $out 'student') -File){if((Get-Content $file.FullName -Raw -Encoding UTF8).Contains('TEACHER_SENTINEL_NOT_STUDENT')){throw 'Student file leak'}};$passed++
$lesson=Test-CoursewareLesson -LessonPath (Join-Path $out 'ppt/lesson.json')
if(-not$lesson.valid -or $lesson.physicalSlideCount -ne 10){throw ('Legacy contract failed: '+($lesson|ConvertTo-Json -Depth 6))};$passed++
$state=Get-Content (Join-Path $out 'ppt/assets/math-state.json') -Raw|ConvertFrom-Json
for($i=0;$i -lt 3;$i++){
    if([math]::Abs($state.XY.vector[$i]-@(0,-1,0)[$i]) -gt 1e-6 -or [math]::Abs($state.YX.vector[$i]-@(1,0,0)[$i]) -gt 1e-6){throw 'Row/column convention mismatch'}
};$passed++
$hash=(Get-FileHash (Join-Path $out 'student/lesson.html')).Hash
$rejected=$false;try{New-CvLessonPackBundle $inputPath $cache $out|Out-Null}catch{$rejected=$true}
if(-not$rejected -or (Get-FileHash (Join-Path $out 'student/lesson.html')).Hash -ne $hash){throw 'Overwrite failure'};$passed++
$p.activity.angleX=0;$p.activity.angleY=60;$p.revision='0.2.1'
[IO.File]::WriteAllText($inputPath,($p|ConvertTo-Json -Depth 20),(New-Object Text.UTF8Encoding($false)))
$new=Join-Path $fixture 'changed';$null=New-CvLessonPackBundle $inputPath $cache $new
$changed=Get-Content (Join-Path $new 'ppt/assets/math-state.json') -Raw|ConvertFrom-Json
if([math]::Abs($changed.XY.vector[0]-[math]::Sqrt(3)/2) -gt 1e-6){throw 'Changed angle did not regenerate figure state'};$passed++
$report=Get-Content (Join-Path $new 'build-report.json') -Raw|ConvertFrom-Json
if($report.revision -ne '0.2.1'){throw 'Revision mismatch'};$passed++
[pscustomobject]@{passed=$passed;failed=0;output=$out;powerPoint=[bool]$IncludePowerPoint}|ConvertTo-Json
