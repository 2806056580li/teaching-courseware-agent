import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const browser=await chromium.launch({channel:'msedge',headless:true});
let passed=0;
try {
  for(const mode of ['texture','webgl']){
    const context=await browser.newContext({offline:true});
    await context.addInitScript(mode=>{
      if(mode==='texture')window.createImageBitmap=()=>Promise.reject(new Error('Injected texture failure'));
      else {
        const original=HTMLCanvasElement.prototype.getContext;
        HTMLCanvasElement.prototype.getContext=function(type,...args){return /^webgl/.test(type)?null:original.call(this,type,...args);};
      }
    },mode);
    const page=await context.newPage(),external=[];
    page.on('request',r=>{if(/^https?:/.test(r.url()))external.push(r.url());});
    await page.goto(pathToFileURL(path.resolve(process.argv[2])).href);
    await page.waitForTimeout(1800);
    assert.equal(await page.locator('.fallback:not([hidden])').count(),2,`${mode}: both scenes must fall back`);
    assert.equal(await page.locator('[data-ready="true"]').count(),0);
    await page.locator('#next-step').click();await page.locator('#next-step').click();
    assert.equal(await page.locator('#step-value').textContent(),'2 / 2');
    assert.match((await page.locator('.vector-result').allTextContents())[0],/0[,.\s]+-1[,.\s]+0/);
    assert.deepEqual(external,[]);passed+=5;await context.close();
  }
  console.log(JSON.stringify({passed,failed:0}));
} finally {await browser.close();}
