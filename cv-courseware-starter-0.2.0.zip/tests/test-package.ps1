#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ResourceDirectory)
$ErrorActionPreference='Stop'
$repo=Split-Path -Parent $PSScriptRoot
$cache=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($ResourceDirectory)
$skill=Join-Path $repo 'skills/cv-courseware'
if (-not (Test-Path -LiteralPath $skill)) { $skill=Join-Path $repo 'cv-courseware' }
$fixture=Join-Path ([IO.Path]::GetTempPath()) ('cv-pack-test-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory((Join-Path $fixture 'scripts'))
[void][IO.Directory]::CreateDirectory((Join-Path $fixture 'tests'))
Copy-Item -LiteralPath $skill -Destination (Join-Path $fixture 'cv-courseware') -Recurse
Copy-Item -LiteralPath (Join-Path $repo 'scripts/Pack-Skill.ps1') -Destination (Join-Path $fixture 'scripts/Pack-Skill.ps1')
Copy-Item -LiteralPath (Join-Path $repo 'scripts/Package.Archive.ps1') -Destination (Join-Path $fixture 'scripts/Package.Archive.ps1')
Copy-Item -LiteralPath (Join-Path $repo 'scripts/build-web.mjs') -Destination (Join-Path $fixture 'scripts/build-web.mjs')
Copy-Item -LiteralPath (Join-Path $repo 'web-src') -Destination (Join-Path $fixture 'web-src') -Recurse
foreach($name in @('package.json','pnpm-lock.yaml')){Copy-Item -LiteralPath (Join-Path $repo $name) -Destination (Join-Path $fixture $name)}
foreach($name in @('INSTALL.md','demo-3d.json')) { Copy-Item -LiteralPath (Join-Path $repo $name) -Destination (Join-Path $fixture $name) }
foreach($name in @('test-input.ps1','test-build.ps1','test-resources.ps1','test-package.ps1','test-lesson-pack.ps1','test-lesson-pack-export.ps1','test-teacher-install.ps1','test-review-regressions.ps1','euler-math.test.mjs','lesson-pack-browser.test.mjs','lesson-pack-fallback.test.mjs')) { Copy-Item -LiteralPath (Join-Path $repo ('tests/'+$name)) -Destination (Join-Path $fixture ('tests/'+$name)) }
'Synthetic packaging test report.' | Set-Content -LiteralPath (Join-Path $fixture 'TEST_REPORT.md') -Encoding UTF8
'{"privateLesson":"Synthetic teacher-only material"}' | Set-Content -LiteralPath (Join-Path $fixture 'cv-courseware/teacher-lesson.json') -Encoding UTF8
$engine=(Get-Process -Id $PID).Path
$pack=Join-Path $fixture 'scripts/Pack-Skill.ps1'
$output=Join-Path $fixture 'public.zip'
$result=& $engine -NoProfile -File $pack -ResourceDirectory $cache -OutputPath $output
if($LASTEXITCODE -ne 0){throw ('Valid packaging failed: '+($result -join "`n"))}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::OpenRead($output)
try {
    if($zip.GetEntry('cv-courseware/teacher-lesson.json')){throw 'FAIL: non-allowlisted teacher JSON entered ZIP'}
    if(-not $zip.GetEntry('cv-courseware/SKILL.md')){throw 'FAIL: entrypoint missing'}
    if(-not $zip.GetEntry('demo-3d.json')){throw 'FAIL: demo missing'}
    if(-not $zip.GetEntry('cv-courseware/templates/web/courseware.bundle.js')){throw 'FAIL: offline runtime missing'}
    if(-not $zip.GetEntry('examples/euler/student/lesson.html')){throw 'FAIL: runnable offline example missing'}
    if(-not $zip.GetEntry('web-src/euler-math.mjs')){throw 'FAIL: auditable source missing'}
}finally{$zip.Dispose()}
Write-Output 'PASS: explicit release scope excludes extra teacher JSON and retains required files'
$existingHash=(Get-FileHash -LiteralPath $output).Hash
$result=& $engine -NoProfile -File $pack -ResourceDirectory $cache -OutputPath $output 2>&1
if($LASTEXITCODE -eq 0 -or (Get-FileHash -LiteralPath $output).Hash -ne $existingHash){throw 'FAIL: package overwrite was not rejected'}
Write-Output 'PASS: existing package remains unchanged'
foreach($relative in @('templates/web/courseware.bundle.js','templates/web/THIRD_PARTY_NOTICES.md')){
    $target=Join-Path $fixture ('cv-courseware/'+$relative)
    $bytes=[IO.File]::ReadAllBytes($target)
    $bad=Join-Path $fixture (([IO.Path]::GetFileNameWithoutExtension($relative))+'.zip')
    try {
        [IO.File]::AppendAllText($target,"`ncorruption-fixture")
        $result=& $engine -NoProfile -File $pack -ResourceDirectory $cache -OutputPath $bad 2>&1
        if($LASTEXITCODE -eq 0 -or (Test-Path -LiteralPath $bad)){throw 'FAIL: changed runtime or license was published'}
    }finally{[IO.File]::WriteAllBytes($target,$bytes)}
    Write-Output ('PASS: integrity mismatch blocks publication: '+$relative)
}
$examplePath=Join-Path $fixture 'cv-courseware/templates/example.json'
$example=Get-Content -LiteralPath $examplePath -Raw -Encoding UTF8 | ConvertFrom-Json
$example.slides[0].notes=('C:'+'\Users\'+'ReviewFixture\Desktop\private-notes.pdf')
$example | ConvertTo-Json -Depth 9 | Set-Content -LiteralPath $examplePath -Encoding UTF8
$leak=Join-Path $fixture 'leak.zip'
$result=& $engine -NoProfile -File $pack -ResourceDirectory $cache -OutputPath $leak 2>&1
if($LASTEXITCODE -eq 0 -or (Test-Path -LiteralPath $leak)){throw 'FAIL: JSON-escaped private path entered package'}
Write-Output 'PASS: decoded JSON strings are scanned for private paths'
Write-Output ('Package tests: 5 passed; isolated fixture retained at '+$fixture)
