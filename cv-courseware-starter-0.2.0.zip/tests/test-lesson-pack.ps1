﻿#requires -Version 5.1
param([string]$ResourceDirectory = '.build/release-cache/resources')
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$skill=Join-Path $root 'skills/cv-courseware'
if(-not(Test-Path $skill)){$skill=Join-Path $root 'cv-courseware'}
$core=Join-Path $skill 'scripts/LessonPack.Core.ps1'
if(-not(Test-Path $core)){throw 'RED: LessonPack.Core.ps1 has not been implemented'}
. $core
$cache=Resolve-CoursewareUserPath $ResourceDirectory
$fixture=Join-Path ([IO.Path]::GetTempPath()) ('lesson-pack-test-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($fixture)
Copy-Item -LiteralPath (Join-Path $skill 'templates/euler/teacher-guide.md') -Destination $fixture
$original=Get-Content -LiteralPath (Join-Path $skill 'templates/euler/lesson-pack.json') -Raw -Encoding UTF8
$path=Join-Path $fixture 'lesson-pack.json'
$passed=0
function Case([string]$Name,[scriptblock]$Change,[bool]$Valid=$false){
    $doc=$original|ConvertFrom-Json
    & $Change $doc
    [IO.File]::WriteAllText($path,($doc|ConvertTo-Json -Depth 20),(New-Object Text.UTF8Encoding($false)))
    $r=Test-CvLessonPack -PackPath $path -ResourceDirectory $cache
    if($r.valid -ne $Valid){throw ($Name+': '+($r|ConvertTo-Json -Depth 6))}
    $script:passed++
}
Case 'valid original' {} $true
foreach($field in @('schemaVersion','lessonId','revision','title','audience','durationMinutes','language','reviewStatus','sources','objectives','concepts','activity','exercises','units','teacherGuide')){
    Case ('missing '+$field) {param($p) $p.PSObject.Properties.Remove($field)}
}
Case 'unknown field' {param($p) $p|Add-Member code 'run me'}
Case 'wrong schema' {param($p) $p.schemaVersion=2}
Case 'string schema' {param($p) $p.schemaVersion='1'}
Case 'bad id' {param($p) $p.lessonId='../escape'}
Case 'bad revision' {param($p) $p.revision='next'}
Case 'long title' {param($p) $p.title='x'*81}
Case 'fractional duration' {param($p) $p.durationMinutes=5.5}
Case 'long audience' {param($p) $p.audience='a'*161}
Case 'bad language' {param($p) $p.language='unknown'}
Case 'bad review' {param($p) $p.reviewStatus='done'}
Case 'script injection' {param($p) $p.title='</script><script>alert(1)</script>'}
Case 'private shareable source' {param($p) $p.sources[0].citation=('C:'+'\Users\'+'SyntheticFixture\secret.pdf')}
Case 'bad source visibility type' {param($p) $p.sources[0].shareWithStudents='false'}
Case 'negative page' {param($p) $p.sources[0].pages=@(-1)}
Case 'duplicate objective' {param($p) $p.objectives[1].id=$p.objectives[0].id}
Case 'missing objective reference' {param($p) $p.concepts[0].objectiveIds=@('missing')}
Case 'missing source reference' {param($p) $p.units[0].sourceIds=@('missing')}
Case 'too many hints' {param($p) $p.exercises[0].hints=@('a','b','c','d')}
Case 'no diagnostic' {param($p) $p.exercises[0].kind='guided'}
Case 'no transfer' {param($p) $p.exercises[4].kind='guided'}
Case 'answer forbidden' {param($p) $p.exercises[0]|Add-Member answer 'secret'}
Case 'wrong unit order' {param($p) $p.units[0].kind='summary'}
Case 'long point' {param($p) $p.units[0].points=@('p'*49)}
Case 'bad angle' {param($p) $p.activity.angleX=181}
Case 'string angle' {param($p) $p.activity.angleY='90'}
Case 'unknown activity' {param($p) $p.activity.kind='execute-js'}
Case 'unknown model' {param($p) $p.activity.modelResourceId='custom'}
Case 'guide traversal' {param($p) $p.teacherGuide='../teacher-guide.md'}
Case 'guide absolute' {param($p) $p.teacherGuide='C:\teacher-guide.md'}
Case 'guide missing' {param($p) $p.teacherGuide='missing.md'}
Case 'guide null' {param($p) $p.teacherGuide=$null}
[IO.File]::WriteAllText($path,$original.Replace('"schemaVersion": 1,','"schemaVersion": 1, "schemaVersion": 1,'))
if((Test-CvLessonPack $path $cache).valid){throw 'Duplicate JSON key accepted'};$passed++
[IO.File]::WriteAllText($path,$original.Replace('"schemaVersion": 1,','"schemaVersion": 1, "\u0073chemaVersion": 1,'))
if((Test-CvLessonPack $path $cache).valid){throw 'Escaped duplicate accepted'};$passed++
$badModel=Join-Path $fixture 'external.glb'
$json=[Text.Encoding]::UTF8.GetBytes('{"asset":{"version":"2.0"},"buffers":[{"uri":"https://invalid.test/x","byteLength":4}]}')
$s=[IO.File]::Create($badModel);$w=New-Object IO.BinaryWriter($s)
$w.Write([uint32]0x46546c67);$w.Write([uint32]2);$w.Write([uint32](20+$json.Length));$w.Write([uint32]$json.Length);$w.Write([uint32]0x4e4f534a);$w.Write($json);$w.Dispose()
$rejected=$false;try{Assert-CvEmbeddedGlb $badModel}catch{$rejected=$true}
if(-not$rejected){throw 'External GLB URI accepted'};$passed++
[pscustomobject]@{passed=$passed;failed=0;powerShell=$PSVersionTable.PSVersion.ToString();fixture=$fixture}|ConvertTo-Json
