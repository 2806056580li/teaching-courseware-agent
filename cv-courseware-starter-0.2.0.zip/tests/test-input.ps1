#requires -Version 5.1
[CmdletBinding()]
param([string]$LogPath)

$ErrorActionPreference = 'Stop'
$skillRoot = Join-Path $PSScriptRoot '../skills/cv-courseware'
if (-not (Test-Path -LiteralPath $skillRoot -PathType Container)) { $skillRoot = Join-Path $PSScriptRoot '../cv-courseware' }
$core = Join-Path $skillRoot 'scripts/Courseware.Core.ps1'
$records = New-Object 'System.Collections.Generic.List[object]'
if (-not (Test-Path -LiteralPath $core -PathType Leaf)) {
    Write-Output 'FAIL: input validator is not implemented (Courseware.Core.ps1 missing).'
    exit 1
}
. $core
if ($LogPath) { $LogPath=Resolve-CoursewareUserPath $LogPath }

$chinese = -join @([char]0x8BFE, [char]0x7A0B)
$root = Join-Path ([IO.Path]::GetTempPath()) ('cv-input-' + [guid]::NewGuid().ToString('N'))
$lessonDirectory = Join-Path $root ($chinese + ' assets [1]')
[void][IO.Directory]::CreateDirectory($lessonDirectory)
$lessonPath = Join-Path $lessonDirectory ($chinese + '.json')
$utf8 = New-Object Text.UTF8Encoding($false)
[IO.File]::WriteAllBytes((Join-Path $lessonDirectory 'image.png'), [Convert]::FromBase64String('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jB9kAAAAASUVORK5CYII='))
[IO.File]::WriteAllText((Join-Path $lessonDirectory 'model.glb'), 'path validation fixture', $utf8)

function New-Fixture {
    return [ordered]@{
        title = $chinese
        slides = @([ordered]@{
            title = $chinese; layout = 'concept'; sourcePages = @(1, 2)
            notes = ''; points = @('A point', $chinese)
        })
    }
}

function Check-Input {
    param([string]$Name, [scriptblock]$Change, [bool]$Valid, [string]$Code, [string]$Raw)
    $fixture = New-Fixture
    if ($Change) { & $Change $fixture }
    if (-not $PSBoundParameters.ContainsKey('Raw')) { $Raw = ConvertTo-Json -InputObject $fixture -Depth 12 }
    [IO.File]::WriteAllText($lessonPath, $Raw, $utf8)
    $result = Test-CoursewareLesson -LessonPath $lessonPath
    $passed = ($result.valid -eq $Valid)
    if ($Code) { $passed = $passed -and (@($result.errors.code) -contains $Code) }
    $records.Add([pscustomobject]@{name=$Name; passed=$passed; errors=@($result.errors)})
    if ($passed) { Write-Output ('PASS: ' + $Name) }
    else { Write-Output ('FAIL: ' + $Name + ': ' + (ConvertTo-Json -InputObject $result -Depth 8 -Compress)) }
}

try {
    Check-Input 'Chinese UTF-8 and literal bracket/space paths' {} $true
    Check-Input 'empty course title' {param($d) $d.title=' '} $false 'text'
    Check-Input 'empty slide title' {param($d) $d.slides[0].title=''} $false 'text'
    Check-Input 'unknown layout' {param($d) $d.slides[0].layout='custom'} $false 'layout'
    Check-Input 'case-sensitive layout' {param($d) $d.slides[0].layout='Concept'} $false 'layout'
    Check-Input 'unknown field is not discarded' {param($d) $d.slides[0].speakerNotes='lost'} $false 'field'
    Check-Input 'incorrect field casing is rejected' {} $false 'field' '{"Title":"x","slides":[]}'
    Check-Input 'missing notes field' {param($d) $d.slides[0].Remove('notes')} $false 'field'
    Check-Input 'long slide title' {param($d) $d.slides[0].title='x'*41} $false 'text'
    Check-Input 'long point' {param($d) $d.slides[0].points=@('x'*49)} $false 'text'
    Check-Input 'four points rejected' {param($d) $d.slides[0].points=@('a','b','c','d')} $false 'points'
    Check-Input 'empty point rejected' {param($d) $d.slides[0].points=@('')} $false 'text'
    Check-Input 'multiline point rejected' {param($d) $d.slides[0].points=@("a`nb")} $false 'text'
    Check-Input 'point scalar rejected' {param($d) $d.slides[0].points='a'} $false 'points'
    Check-Input 'point number rejected' {param($d) $d.slides[0].points=@(12)} $false 'text'
    Check-Input 'slide array required' {param($d) $d.slides=$d.slides[0]} $false 'slides'
    Check-Input 'source pages required as array' {param($d) $d.slides[0].sourcePages=1} $false 'sourcePages'
    Check-Input 'source pages positive integer' {param($d) $d.slides[0].sourcePages=@(0)} $false 'sourcePages'
    Check-Input 'source page fraction rejected' {param($d) $d.slides[0].sourcePages=@(1.5)} $false 'sourcePages'
    Check-Input 'multiline notes preserved' {param($d) $d.slides[0].notes="first`nsecond"} $true
    Check-Input 'notes not coerced' {param($d) $d.slides[0].notes=@('a')} $false 'text'
    Check-Input 'valid relative image' {param($d) $d.slides[0].layout='image'; $d.slides[0].image='image.png'} $true
    Check-Input 'image required' {param($d) $d.slides[0].layout='image'} $false 'field'
    Check-Input 'missing image rejected' {param($d) $d.slides[0].layout='image'; $d.slides[0].image='missing.png'} $false 'asset'
    Check-Input 'URL rejected' {param($d) $d.slides[0].layout='image'; $d.slides[0].image='https://example.org/image.png'} $false 'asset'
    Check-Input 'rooted path rejected' {param($d) $d.slides[0].layout='image'; $d.slides[0].image='C:\image.png'} $false 'asset'
    Check-Input 'drive relative path rejected' {param($d) $d.slides[0].layout='image'; $d.slides[0].image='C:image.png'} $false 'asset'
    Check-Input 'UNC path rejected' {param($d) $d.slides[0].layout='image'; $d.slides[0].image='\\server\image.png'} $false 'asset'
    Check-Input 'parent traversal rejected' {param($d) $d.slides[0].layout='image'; $d.slides[0].image='../image.png'} $false 'asset'
    Check-Input 'internal traversal rejected' {param($d) $d.slides[0].layout='image'; $d.slides[0].image='assets/../image.png'} $false 'asset'
    Check-Input 'alternate data stream rejected' {param($d) $d.slides[0].layout='image'; $d.slides[0].image='image.png:secret'} $false 'asset'
    Check-Input 'wrong image extension' {param($d) $d.slides[0].layout='image'; $d.slides[0].image='model.glb'} $false 'asset'
    Check-Input 'layout cannot discard image' {param($d) $d.slides[0].image='image.png'} $false 'field'
    Check-Input 'equation requires formula' {param($d) $d.slides[0].layout='equation'} $false 'field'
    Check-Input 'editable equation' {param($d) $d.slides[0].layout='equation'; $d.slides[0].formula='R * p + t'} $true
    Check-Input 'Chinese equation text accepted' {param($d) $d.slides[0].layout='equation'; $d.slides[0].formula=$chinese + ': R * p + t'} $true
    Check-Input 'long formula rejected' {param($d) $d.slides[0].layout='equation'; $d.slides[0].formula='x'*73} $false 'text'
    Check-Input 'comparison requires two points' {param($d) $d.slides[0].layout='comparison'; $d.slides[0].points=@('only')} $false 'points'
    Check-Input 'comparison consumes third shared point' {param($d) $d.slides[0].layout='comparison'; $d.slides[0].points=@('left','right','shared')} $true
    Check-Input 'model optional rotation defaults to base only' {param($d) $d.slides[0].layout='model3d'; $d.slides[0].model='model.glb'} $true
    Check-Input 'valid model poses' {param($d) $d.slides[0].layout='model3d'; $d.slides[0].model='model.glb'; $d.slides[0].rotationSteps=@(@{x=18;y=60;z=0},@{x=-18;y=120;z=0})} $true
    Check-Input 'rotation must be array' {param($d) $d.slides[0].layout='model3d'; $d.slides[0].model='model.glb'; $d.slides[0].rotationSteps=@{x=0;y=0;z=0}} $false 'rotation'
    Check-Input 'rotation missing axis' {param($d) $d.slides[0].layout='model3d'; $d.slides[0].model='model.glb'; $d.slides[0].rotationSteps=@(@{x=0;y=20})} $false 'field'
    Check-Input 'rotation range rejected' {param($d) $d.slides[0].layout='model3d'; $d.slides[0].model='model.glb'; $d.slides[0].rotationSteps=@(@{x=0;y=361;z=0})} $false 'rotation'
    Check-Input 'rotation string rejected' {param($d) $d.slides[0].layout='model3d'; $d.slides[0].model='model.glb'; $d.slides[0].rotationSteps=@(@{x=0;y='20';z=0})} $false 'rotation'
    Check-Input 'irrelevant rotation rejected' {param($d) $d.slides[0].rotationSteps=@()} $false 'field'
    Check-Input 'duplicate key rejected before parser discards it' {} $false 'json' '{"title":"first","title":"second","slides":[]}'
    Check-Input 'escaped duplicate key rejected' {} $false 'json' '{"title":"first","\u0074itle":"second","slides":[]}'
    Check-Input 'malformed JSON' {} $false 'json' '{'
    Check-Input 'root array rejected' {} $false 'field' '[]'

    $example = Join-Path $skillRoot 'templates/example.json'
    $exampleResult = Test-CoursewareLesson -LessonPath $example
    $examplePassed = $exampleResult.valid -and $exampleResult.topicCount -eq 4 -and $exampleResult.physicalSlideCount -eq 4
    $records.Add([pscustomobject]@{name='bundled offline example';passed=$examplePassed;errors=@($exampleResult.errors)})
    Write-Output (('{0}: bundled offline example' -f @('FAIL','PASS')[[int]$examplePassed]))

    $d = New-Fixture
    $d.slides[0].layout='model3d'; $d.slides[0].model='model.glb'
    $d.slides[0].rotationSteps=@(@{x=0;y=45;z=0},@{x=0;y=90;z=0})
    [IO.File]::WriteAllText($lessonPath, (ConvertTo-Json -InputObject $d -Depth 12), $utf8)
    $countResult = Test-CoursewareLesson -LessonPath $lessonPath
    $countPassed = $countResult.valid -and $countResult.topicCount -eq 1 -and $countResult.physicalSlideCount -eq 3
    $records.Add([pscustomobject]@{name='one topic plus two poses yields three physical slides';passed=$countPassed})
    Write-Output (('{0}: topic / physical slide counts' -f @('FAIL','PASS')[[int]$countPassed]))

    $outputCases = @(
        @{name='new output path';output=(Join-Path $lessonDirectory 'new.pptx');preview=(Join-Path $lessonDirectory 'new-preview');valid=$true},
        @{name='existing output rejected';output=(Join-Path $lessonDirectory 'image.png');valid=$false},
        @{name='input collision rejected';output=$lessonPath;valid=$false},
        @{name='wrong output extension rejected';output=(Join-Path $lessonDirectory 'new.pdf');valid=$false},
        @{name='existing preview directory rejected';output=(Join-Path $lessonDirectory 'new.pptx');preview=$lessonDirectory;valid=$false},
        @{name='missing output parent rejected';output=(Join-Path $lessonDirectory 'missing/new.pptx');valid=$false}
    )
    foreach ($case in $outputCases) {
        $passed=$false
        try {
            $paths = Get-CoursewareOutputPaths -LessonPath $lessonPath -OutputPath $case.output -PreviewDirectory $case.preview
            $passed=$case.valid -and -not (Test-Path -LiteralPath $paths.outputPath)
        } catch { $passed=(-not $case.valid) -and $_.Exception.Data['CoursewareCode'] -eq 'output' }
        $records.Add([pscustomobject]@{name=$case.name;passed=$passed})
        Write-Output (('{0}: {1}' -f @('FAIL','PASS')[[int]$passed],$case.name))
    }

    $processDirectory = [Environment]::CurrentDirectory
    Push-Location -LiteralPath $lessonDirectory
    try {
        [Environment]::CurrentDirectory = $root
        $relativeLesson = '.\' + [IO.Path]::GetFileName($lessonPath)
        $relativeResult = Test-CoursewareLesson -LessonPath $relativeLesson
        $relativePassed = $relativeResult.valid -and $relativeResult.lessonPath -eq $lessonPath
        $records.Add([pscustomobject]@{name='relative lesson follows Push-Location';passed=$relativePassed;errors=@($relativeResult.errors)})
        Write-Output (('{0}: relative lesson follows Push-Location' -f @('FAIL','PASS')[[int]$relativePassed]))

        $relativePassed=$false
        try {
            $relativeOutput = Get-CoursewareOutputPaths -LessonPath $relativeLesson -OutputPath '.\relative-new.pptx' -PreviewDirectory '.\relative-preview'
            $relativePassed = $relativeOutput.outputPath -eq (Join-Path $lessonDirectory 'relative-new.pptx') -and $relativeOutput.previewDirectory -eq (Join-Path $lessonDirectory 'relative-preview')
        } catch {}
        $records.Add([pscustomobject]@{name='relative output and preview follow Push-Location';passed=$relativePassed})
        Write-Output (('{0}: relative output and preview follow Push-Location' -f @('FAIL','PASS')[[int]$relativePassed]))

        [IO.File]::WriteAllText((Join-Path $lessonDirectory 'existing.pptx'),'existing output sentinel',$utf8)
        [void][IO.Directory]::CreateDirectory((Join-Path $lessonDirectory 'existing-preview'))
        foreach ($case in @(
            @{name='existing relative output rejected after Push-Location';output='.\existing.pptx';preview=$null},
            @{name='existing relative preview rejected after Push-Location';output='.\relative-new.pptx';preview='.\existing-preview'}
        )) {
            $relativePassed=$false
            try { [void](Get-CoursewareOutputPaths -LessonPath $relativeLesson -OutputPath $case.output -PreviewDirectory $case.preview) }
            catch { $relativePassed=$_.Exception.Data['CoursewareCode'] -eq 'output' }
            $records.Add([pscustomobject]@{name=$case.name;passed=$relativePassed})
            Write-Output (('{0}: {1}' -f @('FAIL','PASS')[[int]$relativePassed],$case.name))
        }

        $relativePassed=$false
        try { $relativePassed=(Resolve-CoursewareUserPath '.\model.glb') -eq (Join-Path $lessonDirectory 'model.glb') }
        catch {}
        $records.Add([pscustomobject]@{name='probe model path resolver follows Push-Location';passed=$relativePassed})
        Write-Output (('{0}: probe model path resolver follows Push-Location' -f @('FAIL','PASS')[[int]$relativePassed]))
    }
    finally {
        [Environment]::CurrentDirectory=$processDirectory
        Pop-Location
    }

    # A property-only shape stands in for COM; expectations come from measured Office bounds.
    foreach ($case in @(
        @{name='base model fits the fixed display frame';left=166.0;top=152.0;width=316.0;height=316.0},
        @{name='first rotated model fits the fixed display frame';left=118.955;top=101.377;width=410.089;height=417.246},
        @{name='second rotated model fits the fixed display frame';left=124.908;top=110.908;width=398.183;height=398.183},
        @{name='wide model is centered without stretching';left=0.0;top=0.0;width=1104.0;height=316.0}
    )) {
        $shape=[pscustomobject]@{Left=$case.left;Top=$case.top;Width=$case.width;Height=$case.height;LockAspectRatio=0}
        $fitPassed=$false; $fitError=$null
        try {
            Fit-CoursewareModelFrame $shape
            $fitPassed = $shape.Left -ge 47.99 -and $shape.Top -ge 151.99 -and ($shape.Left+$shape.Width) -le 600.01 -and ($shape.Top+$shape.Height) -le 468.01
            $fitPassed = $fitPassed -and $shape.Width -gt 0 -and $shape.Height -gt 0 -and $shape.LockAspectRatio -eq -1
            $fitPassed = $fitPassed -and [math]::Abs(($shape.Width/$shape.Height)-($case.width/$case.height)) -lt 0.001
            $fitPassed = $fitPassed -and [math]::Abs(($shape.Left+$shape.Width/2)-324) -lt 0.01 -and [math]::Abs(($shape.Top+$shape.Height/2)-310) -lt 0.01
            $fitPassed = $fitPassed -and ([math]::Abs($shape.Width-552) -lt 0.01 -or [math]::Abs($shape.Height-316) -lt 0.01)
        }
        catch { $fitError=$_.Exception.Message }
        $records.Add([pscustomobject]@{name=$case.name;passed=$fitPassed;error=$fitError})
        Write-Output (('{0}: {1} {2}' -f @('FAIL','PASS')[[int]$fitPassed],$case.name,$fitError))
    }

    # Exercise the real GDI+ family names without requiring Office for input tests.
    Add-Type -AssemblyName System.Drawing
    $fontCollection = New-Object Drawing.Text.InstalledFontCollection
    try {
        $fontNames = @($fontCollection.Families | ForEach-Object { $_.GetName(1033) })
        if ($fontNames -contains 'Microsoft YaHei' -and $fontNames -contains 'Cambria') {
            $fontPassed=$false; $fontError=$null
            try { Assert-CoursewareFonts; $fontPassed=$true }
            catch { $fontError=$_.Exception.Message }
            $records.Add([pscustomobject]@{name='installed fonts accepted with localized family names';passed=$fontPassed;error=$fontError})
            Write-Output (('{0}: installed fonts accepted with localized family names {1}' -f @('FAIL','PASS')[[int]$fontPassed],$fontError))
        }
        else { Write-Output 'SKIPPED: localized font regression; required fonts are not installed on this test host.' }
    }
    finally { $fontCollection.Dispose() }
}
finally {
    if ($LogPath) { [IO.File]::WriteAllText($LogPath, (ConvertTo-Json -InputObject @($records.ToArray()) -Depth 8), $utf8) }
    if (([IO.Path]::GetFullPath($root)).StartsWith([IO.Path]::GetTempPath(), [StringComparison]::OrdinalIgnoreCase)) {
        Remove-Item -LiteralPath $root -Recurse -Force
    }
}
$failed = @($records | Where-Object { -not $_.passed }).Count
Write-Output ('Input tests: {0} passed, {1} failed. PowerShell {2}. No COM used.' -f ($records.Count-$failed),$failed,$PSVersionTable.PSVersion)
if ($failed) { exit 1 }
exit 0
