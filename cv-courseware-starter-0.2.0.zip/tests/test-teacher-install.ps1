﻿#requires -Version 5.1
param([Parameter(Mandatory=$true)][string]$ZipPath,[Parameter(Mandatory=$true)][string]$DestinationDirectory)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $DestinationDirectory){throw 'Use a new installation test directory.'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zipFull=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($ZipPath)
$dest=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($DestinationDirectory)
$zip=[IO.Compression.ZipFile]::OpenRead($zipFull)
try{foreach($e in $zip.Entries){if($e.FullName -match '(^|[/\\])\.\.([/\\]|$)|:' -or [IO.Path]::IsPathRooted($e.FullName)){throw 'Unsafe ZIP path'}}}finally{$zip.Dispose()}
[IO.Compression.ZipFile]::ExtractToDirectory($zipFull,$dest)
$manifest=Get-Content -LiteralPath (Join-Path $dest 'package-manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
foreach($f in $manifest.files){$file=Join-Path $dest $f.path;if((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ine $f.sha256){throw ('Hash mismatch: '+$f.path)}}
. (Join-Path $dest 'cv-courseware/scripts/LessonPack.Export.ps1')
$result=New-CvLessonPackBundle -PackPath (Join-Path $dest 'cv-courseware/templates/euler/lesson-pack.json') -ResourceDirectory (Join-Path $dest 'resources') -OutputDirectory (Join-Path $dest 'teacher generated')
if(-not$result.success){throw 'Fresh installation failed'}
[pscustomobject]@{success=$true;verifiedFiles=$manifest.files.Count;output=$result.outputDirectory;runtime='PowerShell and browser; no Node/Python needed for teacher generation';teacherActualMachine='not tested'}|ConvertTo-Json
