#requires -Version 5.1
param([string]$ResourceDirectory='.build/release-cache/resources')
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$skill=Join-Path $root 'skills/cv-courseware';if(-not(Test-Path -LiteralPath $skill)){$skill=Join-Path $root 'cv-courseware'}
. (Join-Path $skill 'scripts/LessonPack.Export.ps1')
$fixture=Join-Path ([IO.Path]::GetTempPath()) ('cv-review-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($fixture)
$results=New-Object 'System.Collections.Generic.List[object]'
function Check([string]$Name,[scriptblock]$Run){
    try{& $Run;$results.Add(@{name=$Name;passed=$true})}catch{$results.Add(@{name=$Name;passed=$false;error=$_.Exception.Message})}
}
$cache=Resolve-CoursewareUserPath $ResourceDirectory
$original=Join-Path $skill 'templates/euler/lesson-pack.json'
Copy-Item -LiteralPath (Join-Path $skill 'templates/euler/teacher-guide.md') -Destination $fixture
Check 'adapted notes rejected before build' {
    $p=Get-Content -LiteralPath $original -Raw -Encoding UTF8|ConvertFrom-Json
    $p.units[0].notes='n'*8000
    $inputPath=Join-Path $fixture 'long.json'
    Write-CvUtf8 $inputPath ($p|ConvertTo-Json -Depth 20)
    if((Test-CvLessonPack $inputPath $cache).valid){throw 'Validator accepted notes exceeding the downstream contract'}
}
Check 'maximum adapted notes preserved' {
    $p=Get-Content -LiteralPath $original -Raw -Encoding UTF8|ConvertFrom-Json
    $p.units[0].notes=''
    $overhead=(Get-CvUnitNotes $p $p.units[0]).Length
    $p.units[0].notes='n'*(8000-$overhead)
    $inputPath=Join-Path $fixture 'limit.json';Write-CvUtf8 $inputPath ($p|ConvertTo-Json -Depth 20)
    $out=Join-Path $fixture 'maximum-notes'
    $null=New-CvLessonPackBundle $inputPath $cache $out
    $lesson=Get-Content -LiteralPath (Join-Path $out 'ppt/lesson.json') -Raw -Encoding UTF8|ConvertFrom-Json
    if($lesson.slides[0].notes.Length -ne 8000 -or -not$lesson.slides[0].notes.StartsWith($p.units[0].notes)){throw 'Notes lost or rejected at valid boundary'}
}
Check 'literal brackets in resource and output paths' {
    $copy=Join-Path $fixture '[resources]';Copy-Item -LiteralPath $cache -Destination $copy -Recurse
    $out=Join-Path $fixture '[output]'
    $null=New-CvLessonPackBundle $original $copy $out
    $report=Get-Content -LiteralPath (Join-Path $out 'build-report.json') -Raw -Encoding UTF8|ConvertFrom-Json
    foreach($f in $report.files){if((Get-FileHash -LiteralPath (Join-Path $out $f.path)).Hash -ine $f.sha256){throw 'Bad bracket-path output hash'}}
}
Check 'archive failure cannot publish final file' {
    . (Join-Path $root 'scripts/Package.Archive.ps1')
    $dir=Join-Path $fixture 'locked-stage';[void][IO.Directory]::CreateDirectory($dir)
    $locked=Join-Path $dir 'locked.txt';Write-CvUtf8 $locked 'fixture'
    $handle=[IO.File]::Open($locked,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $zip=Join-Path $fixture 'locked.zip';$failed=$false
    try{try{Publish-CvPackageArchive $dir $zip 1}catch{$failed=$true}}finally{$handle.Dispose()}
    if(-not$failed -or (Test-Path -LiteralPath $zip)){throw 'Partial final archive was published'}
    Publish-CvPackageArchive $dir $zip 1
    $hash=(Get-FileHash -LiteralPath $zip).Hash;$failed=$false
    try{Publish-CvPackageArchive $dir $zip 1}catch{$failed=$true}
    if(-not$failed -or (Get-FileHash -LiteralPath $zip).Hash -ne $hash){throw 'Final archive was overwritten'}
}
$results|ConvertTo-Json -Depth 4
if(@($results|Where-Object {-not$_.passed}).Count){throw 'Review regression failures'}
