import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const file=process.argv[2];
assert.ok(file,'Usage: node tests/lesson-pack-browser.test.mjs HTML_PATH');
const output=path.resolve('.build/euler-browser');await fs.mkdir(output,{recursive:true});
const browser=await chromium.launch({channel:'msedge',headless:true});
let checks=0;
try {
  for(const [width,height] of [[1440,900],[1920,1080],[390,844]]){
    const context=await browser.newContext({viewport:{width,height},offline:true});
    const page=await context.newPage(), external=[], errors=[];
    page.on('request',r=>{if(/^https?:/.test(r.url()))external.push(r.url());});
    page.on('pageerror',e=>errors.push(e.message));
    page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
    await page.goto(pathToFileURL(path.resolve(file)).href);
    await page.locator('[data-ready="true"]').first().waitFor({timeout:30000});
    assert.equal(await page.locator('[data-ready="true"]').count(),2);checks++;
    const first=page.locator('.scene').first();
    assert.ok((await first.screenshot()).length>5000);checks++;
    const initial=await page.locator('.matrix').allTextContents();
    const before=await first.screenshot(), box=await first.boundingBox();
    await page.mouse.move(box.x+box.width*.45,box.y+box.height*.45);await page.mouse.down();
    await page.mouse.move(box.x+box.width*.75,box.y+box.height*.65,{steps:12});await page.mouse.up();
    await page.waitForTimeout(400);
    assert.notDeepEqual(await first.screenshot(),before);assert.deepEqual(await page.locator('.matrix').allTextContents(),initial);checks+=2;
    assert.equal(await page.locator('#step-value').textContent(),'0 / 2');checks++;
    await page.locator('#next-step').click();await page.locator('#next-step').click();
    await page.waitForTimeout(600);
    assert.equal(await page.locator('#step-value').textContent(),'2 / 2');checks++;
    const vectors=await page.locator('.vector-result').allTextContents();
    assert.match(vectors[0],/0[,.\s]+-1[,.\s]+0/);assert.match(vectors[1],/1[,.\s]+0[,.\s]+0/);checks+=2;
    await page.screenshot({path:path.join(output,`${width}-rotated.png`),fullPage:true});
    await page.locator('#angle-x-number').fill('0');await page.locator('#angle-x-number').press('Tab');
    await page.locator('#angle-y-number').fill('60');await page.locator('#angle-y-number').press('Tab');
    assert.deepEqual((await page.locator('.matrix').allTextContents())[0],(await page.locator('.matrix').allTextContents())[1]);checks++;
    await page.locator('#reset-all').click();assert.equal(await page.locator('#step-value').textContent(),'0 / 2');checks++;
    assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));checks++;
    await page.screenshot({path:path.join(output,`${width}.png`),fullPage:true});
    for(let n=0;n<6;n++){await page.locator('.unit-tab').nth(n).click();assert.equal(await page.locator('.unit-tab[aria-selected="true"]').count(),1);}
    assert.deepEqual(external,[]);assert.deepEqual(errors,[]);checks+=2;
    await page.evaluate(()=>document.querySelector('canvas').dispatchEvent(new Event('webglcontextlost',{cancelable:true})));
    await page.locator('.fallback:not([hidden])').first().waitFor();checks++;
    await context.close();
  }
  console.log(JSON.stringify({passed:checks,failed:0,screenshots:output}));
} finally {await browser.close();}
