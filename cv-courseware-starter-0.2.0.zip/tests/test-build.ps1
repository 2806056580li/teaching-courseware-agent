#requires -Version 5.1
[CmdletBinding()]
param(
    [switch]$RunPowerPoint,
    [string]$ModelPath,
    [string]$ArtifactsDirectory
)

$ErrorActionPreference = 'Stop'
if (-not $RunPowerPoint) {
    Write-Output 'SKIPPED: COM integration test. Run with -RunPowerPoint only when no other Office automation is running. Add -ModelPath <licensed.glb> to include native 3D/Morph acceptance.'
    exit 0
}
$skillRoot = Join-Path $PSScriptRoot '../skills/cv-courseware'
if (-not (Test-Path -LiteralPath $skillRoot -PathType Container)) { $skillRoot = Join-Path $PSScriptRoot '../cv-courseware' }
. (Join-Path $skillRoot 'scripts/Courseware.Core.ps1')
$buildScript = Join-Path $skillRoot 'scripts/Build-Courseware.ps1'
$engine = (Get-Process -Id $PID).Path
$records = New-Object 'System.Collections.Generic.List[object]'
$app = $null; $sentinel = $null; $opened = $null
if (-not $ArtifactsDirectory) { $ArtifactsDirectory = Join-Path ([IO.Path]::GetTempPath()) ('cv-build-' + [guid]::NewGuid().ToString('N')) }
$root = Resolve-CoursewareUserPath $ArtifactsDirectory
if (Test-Path -LiteralPath $root) { throw 'Test artifacts directory must be new.' }
if ($ModelPath) { $ModelPath=Resolve-CoursewareUserPath $ModelPath }
if ($ModelPath -and -not (Test-Path -LiteralPath $ModelPath -PathType Leaf)) { throw 'ModelPath does not exist.' }
[void][IO.Directory]::CreateDirectory($root)
$utf8 = New-Object Text.UTF8Encoding($false)

function Assert-Build {
    param([string]$Name, [bool]$Condition)
    $records.Add([pscustomobject]@{name=$Name;passed=$Condition})
    if (-not $Condition) { throw ('FAIL: ' + $Name) }
    Write-Output ('PASS: ' + $Name)
}

function Read-ZipXml {
    param($Archive, [string]$Name)
    $entry = $Archive.GetEntry($Name)
    if (-not $entry) { throw ('ZIP entry missing: ' + $Name) }
    $reader = New-Object IO.StreamReader($entry.Open())
    try { return [xml]$reader.ReadToEnd() } finally { $reader.Dispose() }
}

try {
    Add-Type -AssemblyName System.Drawing
    $bitmap = New-Object Drawing.Bitmap(320,180)
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    try {
        $graphics.Clear([Drawing.Color]::White)
        $graphics.DrawLine([Drawing.Pens]::Red,40,140,280,140)
        $graphics.DrawLine([Drawing.Pens]::Green,40,140,40,20)
        $graphics.DrawLine([Drawing.Pens]::Blue,40,140,140,50)
        $bitmap.Save((Join-Path $root 'axes.png'),[Drawing.Imaging.ImageFormat]::Png)
    } finally { $graphics.Dispose(); $bitmap.Dispose() }
    $chinese = -join @([char]0x8BFE,[char]0x7A0B)
    $slides = @()
    foreach ($layout in @('title','concept','comparison','image','equation')) {
        $s = [ordered]@{title=($chinese + ' ' + $layout);layout=$layout;sourcePages=@(1,3);notes=('Notes for ' + $layout);points=@('Editable first point','Editable second point','Shared third point')}
        if ($layout -eq 'image') { $s.image='axes.png' }
        if ($layout -eq 'equation') { $s.formula=$chinese + ': p_prime = R * p + t' }
        $slides += $s
    }
    if ($ModelPath) {
        Copy-Item -LiteralPath $ModelPath -Destination (Join-Path $root 'model.glb')
        $slides += [ordered]@{title='Native model';layout='model3d';sourcePages=@(4);notes='Model notes';points=@('Inspect the model orientation.');model='model.glb';rotationSteps=@(@{x=18;y=45;z=0},@{x=18;y=90;z=0})}
    }
    $lessonPath = Join-Path $root ($chinese + ' [1].json')
    [IO.File]::WriteAllText($lessonPath,(ConvertTo-Json -InputObject @{title=$chinese;slides=$slides} -Depth 12),$utf8)
    $output = Join-Path $root ($chinese + ' [1].pptx')
    $preview = Join-Path $root 'preview'

    [void](Get-CoursewareOfficeRegistration)
    $app = New-Object -ComObject PowerPoint.Application
    [void](Assert-CoursewarePowerPoint $app)
    $sentinel = $app.Presentations.Add(0)
    [void]$sentinel.Slides.Add(1,12)
    $sentinelName = $sentinel.Name
    $beforeCount = $app.Presentations.Count
    $buildResult = & $engine -NoProfile -File $buildScript -LessonPath $lessonPath -OutputPath $output -PreviewDirectory $preview
    Assert-Build 'generator exits successfully' ($LASTEXITCODE -eq 0)
    $report = ($buildResult -join "`n") | ConvertFrom-Json
    $expectedPhysical = 5; $expectedTopics = 5
    if ($ModelPath) { $expectedPhysical=8; $expectedTopics=6 }
    Assert-Build 'topic and physical counts are distinct' ($report.topicCount -eq $expectedTopics -and $report.physicalSlideCount -eq $expectedPhysical)
    Assert-Build 'existing presentation remains open' ($sentinel.Name -eq $sentinelName -and $app.Presentations.Count -eq $beforeCount)
    Assert-Build 'all physical slides have PNG previews' (@(Get-ChildItem -LiteralPath $preview -Filter '*.png').Count -eq $expectedPhysical)
    $hashBefore = (Get-FileHash -LiteralPath $output -Algorithm SHA256).Hash
    $reject = & $engine -NoProfile -File $buildScript -LessonPath $lessonPath -OutputPath $output
    Assert-Build 'existing output is rejected without modification' ($LASTEXITCODE -ne 0 -and (Get-FileHash -LiteralPath $output -Algorithm SHA256).Hash -eq $hashBefore)
    $inputHash = (Get-FileHash -LiteralPath $lessonPath -Algorithm SHA256).Hash
    $reject = & $engine -NoProfile -File $buildScript -LessonPath $lessonPath -OutputPath $lessonPath
    Assert-Build 'input collision is rejected without modification' ($LASTEXITCODE -ne 0 -and (Get-FileHash -LiteralPath $lessonPath -Algorithm SHA256).Hash -eq $inputHash)

    $opened = $app.Presentations.Open($output,-1,0,0)
    Assert-Build 'saved deck reopens with expected slide count' ($opened.Slides.Count -eq $expectedPhysical)
    Assert-Build '16:9 dimensions' ([math]::Abs($opened.PageSetup.SlideWidth-960) -lt 0.1 -and [math]::Abs($opened.PageSetup.SlideHeight-540) -lt 0.1)
    for ($i=1; $i -le $opened.Slides.Count; $i++) {
        $slide = $opened.Slides.Item($i)
        Assert-Build ('slide {0} waits for click' -f $i) ($slide.SlideShowTransition.AdvanceOnClick -eq -1 -and $slide.SlideShowTransition.AdvanceOnTime -eq 0)
        $heading = $slide.Shapes.Item('CoursewareTitle')
        Assert-Build ('slide {0} has editable native title' -f $i) ($heading.HasTextFrame -eq -1 -and $heading.TextFrame.TextRange.Text.Length -gt 0)
        Assert-Build ('slide {0} retains notes and source pages' -f $i) ($slide.NotesPage.Shapes.Placeholders.Item(2).TextFrame.TextRange.Text -match 'Source pages:')
        foreach ($shape in $slide.Shapes) {
            if ($shape.HasTextFrame -eq -1 -and $shape.TextFrame.HasText -eq -1) {
                Assert-Build ('slide {0} text fits: {1}' -f $i,$shape.Name) ($shape.TextFrame.TextRange.BoundHeight -le $shape.Height + 1 -and $shape.TextFrame.TextRange.BoundWidth -le $shape.Width + 1)
            }
        }
    }
    $text = $opened.Slides.Item(2).Shapes.Item('CoursewarePoint1').TextFrame.TextRange
    $text.Text = 'Edited in PowerPoint'
    Assert-Build 'body text supports native edits' ($text.Text -eq 'Edited in PowerPoint')
    $formula = $opened.Slides.Item(5).Shapes.Item('CoursewareFormula').TextFrame.TextRange
    Assert-Build 'Chinese formula text survives save exactly' ($formula.Text -eq ($chinese + ': p_prime = R * p + t'))
    Assert-Build 'formula Latin font is Cambria' ($formula.Font.Name -eq 'Cambria')
    Assert-Build 'formula East Asian font is Microsoft YaHei' ($formula.Font.NameFarEast -eq 'Microsoft YaHei')
    if ($ModelPath) {
        for ($i=6; $i -le 8; $i++) {
            $model = $opened.Slides.Item($i).Shapes.Item('!!CoursewareModel')
            Assert-Build ('native model shape on slide ' + $i) ($model.Type -eq 30)
            Assert-Build ('model stays inside fixed display frame on slide ' + $i) ($model.Left -ge 47.9 -and $model.Top -ge 151.9 -and ($model.Left+$model.Width) -le 600.1 -and ($model.Top+$model.Height) -le 468.1)
            Assert-Build ('model stays centered with aspect ratio locked on slide ' + $i) ($model.LockAspectRatio -eq -1 -and [math]::Abs(($model.Left+$model.Width/2)-324) -lt 0.1 -and [math]::Abs(($model.Top+$model.Height/2)-310) -lt 0.1)
            Assert-Build ('topic footer stable on model slide ' + $i) ($opened.Slides.Item($i).Shapes.Item('CoursewareTopic').TextFrame.TextRange.Text -eq 'Topic 6 / 6')
            if ($i -gt 6) {
                $transition = $opened.Slides.Item($i).SlideShowTransition
                Assert-Build ('Morph settings survive save on slide ' + $i) ($transition.EntryEffect -eq 3954 -and [math]::Abs($transition.Duration-1.3) -lt 0.01)
                $expectedY = 45; if ($i -eq 8) { $expectedY=90 }
                Assert-Build ('pose survives save on slide ' + $i) ([math]::Abs($model.Model3D.RotationY-$expectedY) -lt 0.1 -and [math]::Abs($model.Model3D.RotationX-18) -lt 0.1)
            }
        }
    }
    else { Write-Output 'SKIPPED: model/Morph acceptance; no -ModelPath supplied.' }
    $opened.Saved = -1
    $opened.Close(); $opened=$null

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [IO.Compression.ZipFile]::OpenRead($output)
    try {
        Assert-Build 'raster image embedded in package' (@($zip.Entries | Where-Object { $_.FullName -match '^ppt/media/.*\.png$' }).Count -ge 1)
        if ($ModelPath) { Assert-Build 'GLB embedded in package' (@($zip.Entries | Where-Object { $_.FullName -match '^ppt/media/.*\.glb$' }).Count -ge 1) }
        $external = @()
        foreach ($entry in $zip.Entries) {
            if ($entry.FullName -like '*.rels') {
                $xml = Read-ZipXml $zip $entry.FullName
                $external += @($xml.SelectNodes('//*[local-name()="Relationship" and @TargetMode="External"]'))
            }
        }
        Assert-Build 'package has no external asset links' ($external.Count -eq 0)
    } finally { $zip.Dispose() }
    Write-Output ('Build acceptance passed. Artifacts retained: ' + $root)
}
finally {
    if ($opened) { $opened.Saved=-1; $opened.Close() }
    if ($sentinel) { $sentinel.Saved=-1; $sentinel.Close() }
    if ($app) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app) }
    [IO.File]::WriteAllText((Join-Path $root 'test-results.json'),(ConvertTo-Json -InputObject @($records.ToArray()) -Depth 8),$utf8)
}
