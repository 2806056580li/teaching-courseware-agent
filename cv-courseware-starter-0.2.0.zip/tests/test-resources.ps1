﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$Filter = '*')

$ErrorActionPreference = 'Stop'
$skillDirectory = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../skills/cv-courseware'))
if (-not [IO.Directory]::Exists($skillDirectory)) {
    $skillDirectory = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../cv-courseware'))
}
$scriptPath = Join-Path $skillDirectory 'scripts/Get-Resources.ps1'
if (-not [IO.File]::Exists($scriptPath)) {
    Write-Output 'FAIL: portable downloader is not implemented (Get-Resources.ps1 missing).'
    exit 1
}
$engine = (Get-Process -Id $PID).Path
$root = Join-Path ([IO.Path]::GetTempPath()) ('cv-resources-' + [guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($root)
$encoding = New-Object Text.UTF8Encoding($false)
$records = New-Object 'System.Collections.Generic.List[object]'
$hash = 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'
$origin = 'https://raw.githubusercontent.com/fixture/course/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/'

function New-Catalog {
    $items = @()
    foreach ($entry in @(@('license','common','许可/LICENSE'), @('feature','features','特征 [1]/example.py'), @('geometry','geometry','geometry/model.glb'))) {
        $items += [ordered]@{id=$entry[0];topic=$entry[1];path=$entry[2];url=($origin + $entry[0]);sha256=$hash;bytes=3;license='MIT';licenseUrl=($origin+'license');description='中文离线夹具'}
    }
    return [ordered]@{schemaVersion=1;resources=$items}
}

function Require {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

function Invoke-Case {
    param([string]$Name, [scriptblock]$Change, [hashtable]$Options = @{}, [scriptblock]$Assert)
    if ($Name -notlike $Filter) { return }
    $caseRoot = Join-Path $root ([guid]::NewGuid().ToString('N'))
    $destination = Join-Path $caseRoot '中文下载 [1]'
    if ($Options.DeepTargetLength) {
        $padding = [int]$Options.DeepTargetLength - (Join-Path $destination 'LICENSE').Length - 1
        Require ($padding -gt 0 -and $padding -le 200) 'Temporary root is too long for the deep-path fixture.'
        $destination = Join-Path $destination ('d' * $padding)
        $targetLength = (Join-Path $destination 'LICENSE').Length
        $legacyLength = (Join-Path $destination ('.cv-resource-' + ('a' * 32) + '.tmp')).Length
        Require ($targetLength -ge 226 -and $targetLength -le 240 -and $legacyLength -gt 260) 'Deep-path fixture does not reproduce the legacy path limit.'
    }
    [void][IO.Directory]::CreateDirectory($caseRoot)
    $fixture = New-Catalog
    if ($Change) { & $Change $fixture }
    $catalog = Join-Path $caseRoot 'resource-catalog.json'
    $raw = ConvertTo-Json -InputObject $fixture -Depth 12
    if ($Options.ContainsKey('Raw')) { $raw = $Options.Raw }
    [IO.File]::WriteAllText($catalog, $raw, $encoding)
    if ($Options.ContainsKey('Seed')) {
        foreach ($relative in $Options.Seed.Keys) {
            $target = Join-Path $destination $relative
            [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
            [IO.File]::WriteAllText($target, $Options.Seed[$relative], $encoding)
        }
    }
    if ($Options.ContainsKey('Setup')) { & $Options.Setup $destination $caseRoot }
    $arguments = @{Destination=$destination;Catalog=$catalog}
    if ($Options.ContainsKey('Topics')) { $arguments.Topics = $Options.Topics }
    if ($Options.VerifyOnly) { $arguments.VerifyOnly = $true }
    if ($Options.Force) { $arguments.Force = $true }
    if ($Options.CatalogDirectory) { $arguments.Catalog = $caseRoot }
    if ($Options.OmitDestination) { $arguments.Remove('Destination') }
    if ($Options.MissingCatalog) { $arguments.Catalog = Join-Path $caseRoot 'absent.json' }
    if ($Options.DefaultCatalog) { $arguments.Remove('Catalog') }
    $transport = 'forbid'
    if ($Options.Transport) { $transport = $Options.Transport }
    $targetRelative = '特征 [1]/example.py'
    if ($Options.TargetRelative) { $targetRelative = $Options.TargetRelative }
    $transferTrace = Join-Path $caseRoot 'transfer-path.txt'
    $control = Join-Path $caseRoot 'invocation.json'
    [IO.File]::WriteAllText($control, (ConvertTo-Json -InputObject @{script=$scriptPath;arguments=$arguments;transport=$transport;destination=$destination;origin=$origin;targetRelative=$targetRelative;transferTrace=$transferTrace} -Depth 12), $encoding)
    $wrapper = @'
$ErrorActionPreference = 'Stop'
$testControl = Get-Content -LiteralPath '__CONTROL__' -Raw -Encoding UTF8 | ConvertFrom-Json
function Invoke-WebRequest {
    param($Uri, $OutFile, [switch]$UseBasicParsing, [int]$MaximumRedirection, [int]$TimeoutSec, $ErrorAction)
    if ($testControl.transport -eq 'forbid') { throw 'Unexpected network access in an offline test.' }
    if (-not ([string]$Uri).StartsWith($testControl.origin, [StringComparison]::Ordinal)) { throw 'Unexpected URL.' }
    if ($MaximumRedirection -ne 0) { throw 'Redirects must not be followed.' }
    $target = Join-Path $testControl.destination $testControl.targetRelative
    if ($testControl.transport -like 'atomic*') {
        if ([IO.File]::ReadAllText($target) -ne 'bad') { throw 'The old target was modified before validation.' }
        if ([IO.Path]::GetDirectoryName($OutFile) -ne [IO.Path]::GetDirectoryName($target)) { throw 'Temporary file is not a sibling.' }
        if ($OutFile -eq $target) { throw 'Download wrote directly to the target.' }
    }
    if (-not [IO.File]::Exists($OutFile) -or (Get-Item -LiteralPath $OutFile).Length -ne 0) { throw 'Temporary file was not reserved before download.' }
    [IO.File]::WriteAllText($testControl.transferTrace, $OutFile, (New-Object Text.UTF8Encoding($false)))
    $payload = 'abc'
    if ($testControl.transport -eq 'bad-hash') { $payload = 'xyz' }
    if ($testControl.transport -eq 'bad-size') { $payload = 'abcd' }
    if ($testControl.transport -eq 'oversize-valid-hash') { $payload = 'abc' }
    if ($testControl.transport -eq 'atomic-error' -or $testControl.transport -eq 'partial-error') { $payload = 'a' }
    [IO.File]::WriteAllText($OutFile, $payload, (New-Object Text.UTF8Encoding($false)))
    if ($testControl.transport -eq 'atomic-error' -or $testControl.transport -eq 'partial-error') { throw 'Offline transfer interrupted.' }
}
$parameters = @{}
foreach ($property in $testControl.arguments.PSObject.Properties) { $parameters[$property.Name] = $property.Value }
& $testControl.script @parameters
exit $LASTEXITCODE
'@
    $wrapper = $wrapper.Replace('__CONTROL__', $control.Replace("'", "''"))
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($wrapper))
    $oldPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    if ($Options.NativeEntry) {
        $output = @(& $engine -NoProfile -NonInteractive -File $scriptPath -Destination $destination -VerifyOnly 2>&1)
    }
    else { $output = @(& $engine -NoProfile -NonInteractive -EncodedCommand $encoded 2>&1) }
    $exitCode = $LASTEXITCODE
    $ErrorActionPreference = $oldPreference
    try {
        $result = ($output -join "`n") | ConvertFrom-Json -ErrorAction Stop
        & $Assert $result $exitCode $destination $caseRoot
        if ($Options.DeepTargetLength) {
            Require ([IO.File]::Exists($transferTrace)) 'Deep-path test did not reach the simulated download.'
            $temporaryPath = [IO.File]::ReadAllText($transferTrace)
            Require ($temporaryPath.Length -lt 260 -and [IO.Path]::GetFileName($temporaryPath).Length -eq 12) 'Temporary download path is not a short 8.3 name.'
            Require ([IO.Path]::GetDirectoryName($temporaryPath) -eq $destination) 'Deep temporary file is not a sibling of LICENSE.'
        }
        # 随机临时文件的扩展名不固定，因此检查目录中是否存在清单以外的文件。
        if ([IO.Directory]::Exists($destination)) {
            $allowed = @($fixture.resources | ForEach-Object { ([string]$_.path).Replace('\','/') })
            foreach ($file in Get-ChildItem -LiteralPath $destination -File -Recurse -Force) {
                $relative = $file.FullName.Substring($destination.Length + 1).Replace('\','/')
                Require ($allowed -contains $relative) ('Unexpected or temporary download file was left behind: ' + $relative)
            }
        }
        $records.Add([pscustomobject]@{name=$Name;passed=$true})
        Write-Output ('PASS: ' + $Name)
    }
    catch {
        $records.Add([pscustomobject]@{name=$Name;passed=$false;error=$_.Exception.Message})
        Write-Output ('FAIL: ' + $Name + ': ' + $_.Exception.Message + '; output=' + ($output -join ' '))
    }
}

$reject = {
    param($result,$code,$destination)
    Require ($code -ne 0 -and -not $result.success) 'Expected nonzero failure.'
    Require (@($result.errors).Count -gt 0) 'Failure must contain an error.'
    Require (-not [IO.Directory]::Exists($destination)) 'Invalid input created the destination.'
}
$seed = @{'许可/LICENSE'='abc';'特征 [1]/example.py'='abc';'geometry/model.glb'='abc'}
$deepCatalog = {
    param($d)
    $d.resources = @($d.resources[0])
    $d.resources[0].path = 'LICENSE'
}

try {
    Invoke-Case 'bundled catalog resolves from native File entry without Catalog' {} @{VerifyOnly=$true;DefaultCatalog=$true;NativeEntry=$true} {
        param($r,$code,$dest)
        Require ($code -ne 0 -and $r.selected -gt 0 -and $r.failed -eq $r.selected) 'Default catalog was not loaded.'
        Require (@($r.errors | Where-Object {$_.code -ne 'verify'}).Count -eq 0) 'Default catalog failed validation instead of reporting missing files.'
        Require (-not [IO.Directory]::Exists($dest)) 'Default catalog verification created a directory.'
    }
    Invoke-Case 'UTF-8 paths; all topics and common verify offline' {} @{VerifyOnly=$true;Seed=$seed} {
        param($r,$code) Require ($code -eq 0 -and $r.success -and $r.verified -eq 3 -and $r.selected -eq 3) 'Expected three verified files.'
    }
    Invoke-Case 'comma-separated topics always include common' {} @{VerifyOnly=$true;Seed=$seed;Topics=@('features, geometry')} {
        param($r,$code) Require ($code -eq 0 -and $r.selected -eq 3) 'Comma-separated selection failed.'
    }
    Invoke-Case 'topic array and commas may be mixed' {} @{VerifyOnly=$true;Seed=$seed;Topics=@('features','geometry,features')} {
        param($r,$code) Require ($code -eq 0 -and $r.selected -eq 3) 'Array selection or de-duplication failed.'
    }
    Invoke-Case 'selection does not require unselected files' {} @{VerifyOnly=$true;Seed=@{'许可/LICENSE'='abc';'特征 [1]/example.py'='abc'};Topics=@('features')} {
        param($r,$code) Require ($code -eq 0 -and $r.selected -eq 2 -and $r.verified -eq 2) 'Feature and license selection failed.'
    }
    Invoke-Case 'catalog can be a containing directory' {} @{VerifyOnly=$true;Seed=$seed;CatalogDirectory=$true} {
        param($r,$code) Require ($code -eq 0 -and $r.verified -eq 3) 'Directory catalog input failed.'
    }
    Invoke-Case 'cached files skip all network requests' {} @{Seed=$seed} {
        param($r,$code) Require ($code -eq 0 -and $r.cached -eq 3 -and $r.downloaded -eq 0) 'Valid cache was not reused.'
    }
    Invoke-Case 'Force still skips a valid cache' {} @{Seed=$seed;Force=$true} {
        param($r,$code) Require ($code -eq 0 -and $r.cached -eq 3) 'Force re-downloaded a valid cache.'
    }
    Invoke-Case 'VerifyOnly missing files fails without creating directories' {} @{VerifyOnly=$true;Force=$true} {
        param($r,$code,$dest) Require ($code -ne 0 -and $r.failed -eq 3 -and -not [IO.Directory]::Exists($dest)) 'VerifyOnly had side effects or ignored missing files.'
    }
    Invoke-Case 'common license is required for every selection' {} @{VerifyOnly=$true;Seed=@{'特征 [1]/example.py'='abc'};Topics=@('features')} {
        param($r,$code) Require ($code -ne 0 -and $r.failed -eq 1 -and $r.verified -eq 1) 'Missing common license did not fail.'
    }
    Invoke-Case 'corrupt same-size cache is preserved by default' {} @{Seed=@{'许可/LICENSE'='abc';'特征 [1]/example.py'='xyz'};Topics=@('features')} {
        param($r,$code,$dest) Require ($code -ne 0 -and $r.failed -eq 1) 'Corrupt cache was accepted.'
        Require ([IO.File]::ReadAllText((Join-Path $dest '特征 [1]/example.py')) -eq 'xyz') 'Corrupt cache was overwritten without Force.'
    }
    Invoke-Case 'wrong-size cache is rejected in VerifyOnly' {} @{VerifyOnly=$true;Seed=@{'许可/LICENSE'='abc';'特征 [1]/example.py'='ab'};Topics=@('features')} {
        param($r,$code) Require ($code -ne 0 -and $r.failed -eq 1) 'Wrong-size cache was accepted.'
    }
    Invoke-Case 'download validates and installs original bytes' {} @{Transport='ok';Topics=@('features')} {
        param($r,$code,$dest) Require ($code -eq 0 -and $r.downloaded -eq 2) 'Expected resource plus common license download.'
        Require ([IO.File]::ReadAllText((Join-Path $dest '特征 [1]/example.py')) -eq 'abc') 'Downloaded bytes changed.'
    }
    Invoke-Case 'bad downloaded hash never becomes a target' {} @{Transport='bad-hash';Topics=@('features')} {
        param($r,$code,$dest) Require ($code -ne 0 -and $r.downloaded -eq 0) 'Bad download hash was accepted.'
        Require (-not [IO.File]::Exists((Join-Path $dest '特征 [1]/example.py'))) 'Bad bytes were installed.'
    }
    Invoke-Case 'bad downloaded size never becomes a target' {} @{Transport='bad-size';Topics=@('features')} {
        param($r,$code,$dest) Require ($code -ne 0 -and -not [IO.File]::Exists((Join-Path $dest '特征 [1]/example.py'))) 'Bad download size was accepted.'
    }
    Invoke-Case 'valid hash with incorrect declared size still fails' {param($d) $d.resources[1].bytes=2} @{Transport='oversize-valid-hash';Topics=@('features')} {
        param($r,$code,$dest) Require ($code -ne 0 -and -not [IO.File]::Exists((Join-Path $dest '特征 [1]/example.py'))) 'SHA alone incorrectly accepted the payload.'
    }
    Invoke-Case 'Force uses a validated sibling then atomically replaces' {} @{Transport='atomic-ok';Force=$true;Topics=@('features');Seed=@{'许可/LICENSE'='abc';'特征 [1]/example.py'='bad'}} {
        param($r,$code,$dest) Require ($code -eq 0 -and $r.downloaded -eq 1 -and $r.cached -eq 1) 'Force replacement failed.'
        Require ([IO.File]::ReadAllText((Join-Path $dest '特征 [1]/example.py')) -eq 'abc') 'Validated replacement missing.'
    }
    Invoke-Case 'failed Force preserves the old file and cleans temporary bytes' {} @{Transport='atomic-error';Force=$true;Topics=@('features');Seed=@{'许可/LICENSE'='abc';'特征 [1]/example.py'='bad'}} {
        param($r,$code,$dest) Require ($code -ne 0 -and [IO.File]::ReadAllText((Join-Path $dest '特征 [1]/example.py')) -eq 'bad') 'Interrupted replacement destroyed the original.'
    }
    Invoke-Case 'partial failed download leaves no final file' {} @{Transport='partial-error';Topics=@('features')} {
        param($r,$code,$dest) Require ($code -ne 0 -and -not [IO.File]::Exists((Join-Path $dest '特征 [1]/example.py'))) 'Partial download was installed.'
    }
    Invoke-Case 'deep path 226 downloads a verified LICENSE' $deepCatalog @{DeepTargetLength=226;TargetRelative='LICENSE';Transport='ok'} {
        param($r,$code,$dest)
        Require ($code -eq 0 -and $r.success -and $r.downloaded -eq 1) 'Deep-path download failed.'
        Require ([IO.File]::ReadAllText((Join-Path $dest 'LICENSE')) -eq 'abc') 'Deep-path download bytes changed.'
    }
    Invoke-Case 'deep path 236 Force atomically replaces LICENSE' $deepCatalog @{DeepTargetLength=236;TargetRelative='LICENSE';Transport='atomic-ok';Force=$true;Seed=@{LICENSE='bad'}} {
        param($r,$code,$dest)
        Require ($code -eq 0 -and $r.success -and $r.downloaded -eq 1) 'Deep-path Force replacement failed.'
        Require ([IO.File]::ReadAllText((Join-Path $dest 'LICENSE')) -eq 'abc') 'Deep-path validated replacement missing.'
    }
    Invoke-Case 'deep path 240 interrupted Force preserves LICENSE and cleans up' $deepCatalog @{DeepTargetLength=240;TargetRelative='LICENSE';Transport='atomic-error';Force=$true;Seed=@{LICENSE='bad'}} {
        param($r,$code,$dest)
        Require ($code -ne 0 -and $r.failed -eq 1 -and $r.errors[0].message -like '*Offline transfer interrupted*') 'Expected a simulated interruption after creating the deep temporary file.'
        Require ([IO.File]::ReadAllText((Join-Path $dest 'LICENSE')) -eq 'bad') 'Deep-path interrupted replacement destroyed the original.'
    }
    Invoke-Case 'deep path 240 invalid hash leaves no LICENSE or temporary file' $deepCatalog @{DeepTargetLength=240;TargetRelative='LICENSE';Transport='bad-hash'} {
        param($r,$code,$dest)
        Require ($code -ne 0 -and $r.failed -eq 1 -and $r.errors[0].code -eq 'integrity') 'Expected deep downloaded bytes to fail hash validation.'
        Require (-not [IO.File]::Exists((Join-Path $dest 'LICENSE'))) 'Deep-path invalid download was installed.'
    }
    Invoke-Case 'unknown selected topic rejected' {} @{Topics=@('unknown')} $reject
    Invoke-Case 'empty comma topic rejected' {} @{Topics=@('features,,geometry')} $reject
    Invoke-Case 'Destination is required without an interactive prompt' {} @{OmitDestination=$true} $reject
    Invoke-Case 'missing catalog rejected' {} @{MissingCatalog=$true} $reject
    Invoke-Case 'empty catalog rejected' {param($d) $d.resources=@()} @{} $reject
    Invoke-Case 'malformed JSON rejected' {} @{Raw='{'} $reject
    Invoke-Case 'root array rejected' {} @{Raw='[]'} $reject
    Invoke-Case 'unsupported schema rejected' {param($d) $d.schemaVersion=2} @{} $reject
    Invoke-Case 'string schema rejected' {param($d) $d.schemaVersion='1'} @{} $reject
    Invoke-Case 'resources object rejected' {param($d) $d.resources=$d.resources[0]} @{} $reject
    Invoke-Case 'null resource rejected' {param($d) $d.resources=@($null)} @{} $reject
    Invoke-Case 'unknown catalog topic rejected' {param($d) $d.resources[1].topic='other'} @{} $reject
    Invoke-Case 'missing license evidence rejected' {param($d) $d.resources[1].Remove('licenseUrl')} @{} $reject
    Invoke-Case 'empty license rejected' {param($d) $d.resources[1].license=''} @{} $reject
    Invoke-Case 'short SHA256 rejected' {param($d) $d.resources[1].sha256='abc'} @{} $reject
    Invoke-Case 'nonhex SHA256 rejected' {param($d) $d.resources[1].sha256='z'*64} @{} $reject
    foreach ($value in @(-1,0,1.5,'3',$null)) {
        Invoke-Case ('invalid byte count ' + [string]$value) {param($d) $d.resources[1].bytes=$value} @{} $reject
    }
    Invoke-Case 'duplicate ID rejected' {param($d) $d.resources[1].id='license'} @{} $reject
    Invoke-Case 'case-folded duplicate path rejected' {param($d) $d.resources[1].path='许可/license'} @{} $reject
    Invoke-Case 'slash alias duplicate path rejected' {param($d) $d.resources[1].path='许可\LICENSE'} @{} $reject
    Invoke-Case 'file-directory prefix collision rejected' {param($d) $d.resources[1].path='许可/LICENSE/child'} @{} $reject
    Invoke-Case 'invalid unselected path is rejected before any download' {param($d) $d.resources[2].path='../escape'} @{Topics=@('features');Transport='ok'} $reject
    foreach ($value in @('../escape','a/../escape','C:\escape','C:escape','/escape','\escape','\\server\share\file','a:stream','a/b:stream','a//b','a/./b','a./b','a /b','CON.txt','a/NUL','a/*','a/?',('a/'+[char]1))) {
        Invoke-Case ('unsafe relative path ' + $value) {param($d) $d.resources[1].path=$value} @{} $reject
    }
    foreach ($value in @(('http://raw.githubusercontent.com/x/y/' + ('a'*40) + '/file'),'file:///C:/file','https://example.org/file','https://raw.githubusercontent.com/x/y/main/file',('https://raw.githubusercontent.com.evil.test/x/y/'+('a'*40)+'/file'),('https://user@raw.githubusercontent.com/x/y/'+('a'*40)+'/file'),($origin+'feature?token=x'),($origin+'../feature'),($origin+'%2e%2e/feature'))) {
        Invoke-Case ('unsafe URL ' + $value) {param($d) $d.resources[1].url=$value} @{} $reject
    }
    Invoke-Case 'unsafe license URL rejected' {param($d) $d.resources[1].licenseUrl='http://example.org/license'} @{} $reject
    Invoke-Case 'license evidence outside common or own file rejected' {param($d) $d.resources[1].licenseUrl=$d.resources[2].url} @{} $reject
    Invoke-Case 'duplicate JSON keys rejected consistently' {} @{Raw='{"schemaVersion":1,"schemaVersion":1,"resources":[]}'} $reject
    Invoke-Case 'junction cannot redirect a resource outside destination' {} @{Setup={param($dest,$caseRoot)
        [void][IO.Directory]::CreateDirectory($dest)
        $outside=Join-Path $caseRoot 'outside'
        [void][IO.Directory]::CreateDirectory($outside)
        [void](New-Item -ItemType Junction -Path (Join-Path $dest '特征 [1]') -Target $outside)
    };Topics=@('features');Transport='ok'} {
        param($r,$code,$dest,$caseRoot) Require ($code -ne 0 -and -not [IO.File]::Exists((Join-Path $caseRoot 'outside/example.py'))) 'Junction escaped the download root.'
        Remove-Item -LiteralPath (Join-Path $dest '特征 [1]') -Force
    }
}
finally {
    $resolved = [IO.Path]::GetFullPath($root)
    $tempBase = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd([char[]]'\/') + [IO.Path]::DirectorySeparatorChar
    if ($resolved.StartsWith($tempBase,[StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetFileName($resolved).StartsWith('cv-resources-')) {
        Remove-Item -LiteralPath $resolved -Recurse -Force
    }
}
$failures = @($records | Where-Object { -not $_.passed })
if ($records.Count -eq 0) { Write-Output 'FAIL: no tests matched the filter.'; exit 1 }
Write-Output ('Resource tests: {0} passed, {1} failed. PowerShell {2}. Offline; no COM.' -f ($records.Count-$failures.Count),$failures.Count,$PSVersionTable.PSVersion)
if ($failures.Count) { exit 1 }
exit 0
