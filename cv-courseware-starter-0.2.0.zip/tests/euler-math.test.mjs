import test from 'node:test';
import assert from 'node:assert/strict';
import { composeEuler } from '../web-src/euler-math.mjs';

const close = (actual, expected, eps=1e-10) => actual.forEach((n,i)=>assert.ok(Math.abs(n-expected[i])<eps, `${actual} != ${expected}`));
test('identity and analytic fixed-axis results',()=>{
  close(composeEuler({angleX:70,angleY:20,order:'XY',step:0}).matrixRows,[1,0,0,0,1,0,0,0,1]);
  close(composeEuler({angleX:90,angleY:0,order:'XY',step:2}).vector,[0,-1,0]);
  close(composeEuler({angleX:0,angleY:90,order:'XY',step:2}).vector,[1,0,0]);
  close(composeEuler({angleX:90,angleY:90,order:'XY',step:2}).vector,[0,-1,0]);
  close(composeEuler({angleX:90,angleY:90,order:'YX',step:2}).vector,[1,0,0]);
});
test('matrix order, intermediate step, zero-angle exception',()=>{
  close(composeEuler({angleX:90,angleY:90,order:'XY',step:2}).matrixRows,[0,1,0,0,0,-1,-1,0,0]);
  close(composeEuler({angleX:90,angleY:90,order:'YX',step:2}).matrixRows,[0,0,1,1,0,0,0,1,0]);
  close(composeEuler({angleX:90,angleY:90,order:'XY',step:1}).vector,[0,-1,0]);
  close(composeEuler({angleX:0,angleY:60,order:'XY',step:2}).vector,[Math.sqrt(3)/2,0,.5]);
  close(composeEuler({angleX:0,angleY:60,order:'YX',step:2}).vector,[Math.sqrt(3)/2,0,.5]);
});
test('rotation matrices stay orthonormal with determinant one',()=>{
  let seed=927;
  const rand=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/2**32*360-180;};
  for(let n=0;n<100;n++)for(const order of ['XY','YX']){
    const m=composeEuler({angleX:rand(),angleY:rand(),order,step:2}).matrixRows;
    for(let i=0;i<3;i++)for(let j=0;j<3;j++)close([m[i*3]*m[j*3]+m[i*3+1]*m[j*3+1]+m[i*3+2]*m[j*3+2]],[i===j?1:0]);
    close([m[0]*(m[4]*m[8]-m[5]*m[7])-m[1]*(m[3]*m[8]-m[5]*m[6])+m[2]*(m[3]*m[7]-m[4]*m[6])],[1]);
  }
});
test('reject invalid inputs',()=>{
  for(const bad of [{angleX:NaN},{angleY:Infinity},{angleX:181},{angleY:'90'},{step:3},{step:.5},{order:'xx'}]){
    assert.throws(()=>composeEuler({angleX:90,angleY:90,order:'XY',step:2,...bad}));
  }
});
